document.addEventListener('DOMContentLoaded', () => {
    const customersTable = document.getElementById('customers-table'); // This should be customers-table
    
    // Only run the script if the customers table and data exist on the page
    if (customersTable && typeof mobileCustomers !== 'undefined') {
        const tableBody = customersTable.querySelector('tbody');
        const searchInput = document.getElementById('customer-search');
        const printBtn = document.getElementById('print-customers-btn');
        const selectAllCheckbox = document.getElementById('select-all-customers');
        const deleteSelectedBtn = document.getElementById('delete-selected-customers-btn');
        const noResultsRow = customersTable.querySelector('.no-results-row');
        const loader = document.querySelector('.customer-list-container .table-loader');

        // Delete Modal Elements
        const confirmOverlay = document.getElementById('delete-confirm-overlay');
        const confirmModal = document.getElementById('delete-confirm-modal');
        const confirmMessage = document.getElementById('delete-confirm-message');
        const confirmBtn = document.getElementById('delete-confirm-btn');
        const cancelBtn = document.getElementById('delete-cancel-btn');
        const closeModalBtn = document.getElementById('delete-confirm-close-btn');

        const successToast = document.getElementById('success-toast');

        // Populate Table
        const populateCustomersTable = () => {
            if(loader) loader.classList.add('loading');
            
            // Use a timeout to simulate loading and allow the loader to be seen
            setTimeout(() => {
                const fragment = document.createDocumentFragment();
                mobileCustomers.forEach((customer, index) => {
                    const row = document.createElement('tr');
                    row.dataset.index = index; // Link row to the data index

                    const verificationBadge = customer.isVerified 
                        ? `<span class="status-badge verified">Verified</span>` 
                        : `<span class="status-badge not-verified">Not Verified</span>`;

                    row.innerHTML = /*html*/`
                        <td><input type="checkbox" class="customer-checkbox"></td>
                        <td>${customer.name}</td>
                        <td>${customer.phone}</td>
                        <td>${customer.plateNumber}</td>
                        <td class="text-center">${verificationBadge}</td>
                        <td class="text-center">${customer.orders}</td>
                        <td>${customer.registrationDate}</td>
                        <td class="text-center actions-cell">
                            <button class="action-icon-btn view-btn" title="View Details">
                                <span class="material-symbols-outlined">info</span>
                            </button>
                            <button class="action-icon-btn delete-btn" title="Delete Customer">
                                <span class="material-symbols-outlined">delete</span>
                            </button>
                        </td>
                    `;
                    fragment.appendChild(row);
                });
                tableBody.prepend(fragment);
                if(loader) loader.classList.remove('loading');
            }, 300); // 300ms delay
        };

        // Search Functionality
        const filterCustomers = () => {
            const searchTerm = searchInput.value.toLowerCase();
            const rows = tableBody.querySelectorAll('tr:not(.no-results-row)');
            let visibleRows = 0;

            rows.forEach(row => {
                const name = row.children[1].textContent.toLowerCase();
                const phone = row.children[2].textContent.toLowerCase();
                const plate = row.children[3].textContent.toLowerCase();

                if (name.includes(searchTerm) || phone.includes(searchTerm) || plate.includes(searchTerm)) {
                    row.style.display = '';
                    visibleRows++;
                } else {
                    row.style.display = 'none';
                }
            });

            noResultsRow.style.display = visibleRows === 0 ? '' : 'none';
        };

        // Checkbox Logic
        const updateDeleteButtonState = () => {
            const checkedBoxes = tableBody.querySelectorAll('.customer-checkbox:checked');
            deleteSelectedBtn.disabled = checkedBoxes.length === 0;
        };

        // --- Delete Modal Logic ---
        const openConfirmModal = (count) => {
            confirmMessage.textContent = `Are you sure you want to delete ${count} selected customer(s)? This action cannot be undone.`;
            confirmOverlay.classList.add('show');
        };

        const closeConfirmModal = () => {
            confirmOverlay.classList.remove('show');
        };

        // --- Success Toast Notification ---
        const showSuccessToast = (message) => {
            if (!successToast) return;
            const toastText = successToast.querySelector('p');
            toastText.textContent = message;
            successToast.classList.add('show');

            // Hide after 3 seconds
            setTimeout(() => {
                successToast.classList.remove('show');
            }, 3000);
        };


        // Delete Selected Functionality
        const deleteSelectedCustomers = () => {
            const checkedBoxes = tableBody.querySelectorAll('.customer-checkbox:checked');
            const count = checkedBoxes.length;

            if (count === 0) {
                // This case should ideally not be hit since the button is disabled, but it's good practice.
                alert('Please select at least one customer to delete.');
                return;
            }

            openConfirmModal(count);

            // Use { once: true } to automatically remove the event listener after it's fired once.
            // This prevents multiple listeners from being attached if the modal is opened again.
            confirmBtn.addEventListener('click', () => {
                checkedBoxes.forEach(checkbox => {
                    checkbox.closest('tr').remove();
                });

                // Update UI after deletion
                closeConfirmModal();
                updateDeleteButtonState();
                selectAllCheckbox.checked = false;
                filterCustomers(); // Re-run filter to show/hide the "No results" message if needed
                showSuccessToast(`${count} customer(s) successfully deleted.`);
            }, { once: true });
        };

        // Event Listeners
        searchInput.addEventListener('input', filterCustomers);
        printBtn.addEventListener('click', () => window.print());
        deleteSelectedBtn.addEventListener('click', deleteSelectedCustomers);
        selectAllCheckbox.addEventListener('change', (e) => {
            tableBody.querySelectorAll('.customer-checkbox').forEach(checkbox => checkbox.checked = e.target.checked);
            updateDeleteButtonState();
        });
        tableBody.addEventListener('change', (e) => {
            if (e.target.classList.contains('customer-checkbox')) {
                updateDeleteButtonState();
                if (!e.target.checked) selectAllCheckbox.checked = false;
            }
        });
        tableBody.addEventListener('click', (e) => {
            const viewButton = e.target.closest('.view-btn');
            const deleteButton = e.target.closest('.delete-btn');
            const checkbox = e.target.closest('.customer-checkbox');
            const row = e.target.closest('tr');

            if (!row || row.classList.contains('no-results-row')) return;

            // If the click was on the row itself or the view button (but not on another action button/checkbox), navigate to the profile page
            const isActionClick = deleteButton || checkbox;
            if (!isActionClick) {
                const customerIndex = row.dataset.index;
                const customer = mobileCustomers[customerIndex];

                if (customer) {
                    // The customer object from mobileCustomers already has all the needed details.
                    // We just need to pass it in the expected format for customer-profile.js
                    const profileData = { ...customer, customer: customer.name, plate: customer.plateNumber, service: customer.lastService };
                    sessionStorage.setItem('selectedProfileData', JSON.stringify(profileData));
                    window.location.href = 'customer-profile.html';
                }
            }
        });

        // Delete Modal event listeners
        cancelBtn.addEventListener('click', closeConfirmModal);
        closeModalBtn.addEventListener('click', closeConfirmModal);
        confirmOverlay.addEventListener('click', (e) => {
            if (e.target === confirmOverlay) closeConfirmModal();
        });

        // Initial Population
        populateCustomersTable();
    }
});