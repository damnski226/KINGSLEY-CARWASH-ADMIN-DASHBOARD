document.addEventListener('DOMContentLoaded', () => {
    const editPromotionForm = document.getElementById('edit-promotion-form');
    if (!editPromotionForm) return;

    // --- Get data from sessionStorage ---
    const promoToEditJSON = sessionStorage.getItem('promotionToEdit');
    if (!promoToEditJSON) {
        alert('No promotion selected for editing. Please go back and select one.');
        window.location.href = 'promotions.html';
        return;
    }
    const promoData = JSON.parse(promoToEditJSON);

    // --- Get form elements ---
    const imageInput = document.getElementById('promo-image');
    const imagePreview = document.getElementById('image-preview');
    const imagePreviewImage = imagePreview.querySelector('.image-preview-image');
    const imageUploaderPlaceholder = imagePreview.querySelector('.image-uploader-placeholder');
    const serviceChecklist = document.getElementById('service-checklist');

    // --- Populate Service Checklist ---
    const services = window.appData.services || [];
    if (services.length > 0) {
        const fragment = document.createDocumentFragment();
        services.forEach(service => {
            const isChecked = promoData.services.includes(service.service);
            const item = document.createElement('div');
            item.classList.add('checklist-item');
            item.innerHTML = `
                <input type="checkbox" id="service-${service.serviceId}" name="services" value="${service.service}" ${isChecked ? 'checked' : ''}>
                <label for="service-${service.serviceId}">${service.service}</label>
            `;
            fragment.appendChild(item);
        });
        serviceChecklist.appendChild(fragment);
    }

    // --- Populate Form Fields ---
    document.getElementById('promo-title').value = promoData.title;
    document.getElementById('promo-description').value = promoData.description || '';

    // Populate new price fields
    document.getElementById('promo-price-small').value = promoData.promoPrices?.small || '';
    document.getElementById('promo-price-medium').value = promoData.promoPrices?.medium || '';
    document.getElementById('promo-price-large').value = promoData.promoPrices?.large || '';
    document.getElementById('promo-price-xlarge').value = promoData.promoPrices?.xlarge || '';
    document.getElementById('original-price-small').value = promoData.originalPrices?.small || '';
    document.getElementById('original-price-medium').value = promoData.originalPrices?.medium || '';
    document.getElementById('original-price-large').value = promoData.originalPrices?.large || '';
    document.getElementById('original-price-xlarge').value = promoData.originalPrices?.xlarge || '';

    // Format date for the input field (YYYY-MM-DD)
    document.getElementById('promo-publish-date').value = new Date(promoData.publishDate || promoData.expiryDate).toISOString().split('T')[0];
    document.getElementById('promo-expiry').value = new Date(promoData.expiryDate).toISOString().split('T')[0];

    // --- Populate Image ---
    if (promoData.imageUrl) {
        imagePreviewImage.setAttribute('src', promoData.imageUrl);
        imageUploaderPlaceholder.style.display = 'none';
        imagePreviewImage.style.display = 'block';
    }

    // --- Image Preview Logic ---
    imageInput.addEventListener('change', function () {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            imageUploaderPlaceholder.style.display = 'none';
            imagePreviewImage.style.display = 'block';
            reader.addEventListener('load', function () {
                imagePreviewImage.setAttribute('src', this.result);
            });
            reader.readAsDataURL(file);
        }
    });

    // --- Form Submission Logic (Update) ---
    editPromotionForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // Get updated values
        const selectedServices = [];
        document.querySelectorAll('#service-checklist input[type="checkbox"]:checked').forEach(checkbox => {
            selectedServices.push(checkbox.value);
        });

        const promoPrices = {
            small: parseFloat(document.getElementById('promo-price-small').value) || null,
            medium: parseFloat(document.getElementById('promo-price-medium').value) || null,
            large: parseFloat(document.getElementById('promo-price-large').value) || null,
            xlarge: parseFloat(document.getElementById('promo-price-xlarge').value) || null,
        };
        const originalPrices = {
            small: parseFloat(document.getElementById('original-price-small').value) || null,
            medium: parseFloat(document.getElementById('original-price-medium').value) || null,
            large: parseFloat(document.getElementById('original-price-large').value) || null,
            xlarge: parseFloat(document.getElementById('original-price-xlarge').value) || null,
        };


        const publishDateInput = document.getElementById('promo-publish-date').value;
        const publishDate = new Date(publishDateInput);
        publishDate.setHours(0, 0, 0, 0);

        const expiryDateInput = document.getElementById('promo-expiry').value;
        const expiryDate = new Date(expiryDateInput);
        expiryDate.setHours(23, 59, 59, 999);

        // Create the updated promotion object
        const updatedPromotion = {
            ...promoData, // Keep original ID and other unchanged properties
            title: document.getElementById('promo-title').value,
            description: document.getElementById('promo-description').value,
            promoPrices,
            originalPrices,
            publishDate: publishDate.toISOString(),
            expiryDate: expiryDate.toISOString(),
            imageUrl: imagePreviewImage.getAttribute('src'),
            services: selectedServices,
        };

        // Store the updated promotion to be picked up by the promotions page
        sessionStorage.setItem('updatedPromotion', JSON.stringify(updatedPromotion));

        // Clean up the edit data
        sessionStorage.removeItem('promotionToEdit');

        // Redirect back to the promotions list
        window.location.href = 'promotions.html';
    });

    // Set min date for expiry to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('promo-publish-date').setAttribute('min', today);
    document.getElementById('promo-expiry').setAttribute('min', today);
});