document.addEventListener('DOMContentLoaded', () => {
    const createServiceForm = document.getElementById('create-service-form');
    const imageInput = document.getElementById('service-image');
    const imagePreview = document.getElementById('image-preview');
    const imagePreviewImage = imagePreview.querySelector('.image-preview-image');
    const imageUploaderPlaceholder = imagePreview ? imagePreview.querySelector('.image-uploader-placeholder') : null;

    // Only run if the form exists on the page
    if (!createServiceForm) return;

    // --- Image Preview Logic ---
    imageInput.addEventListener('change', function () {
        const file = this.files[0];

        if (file) {
            const reader = new FileReader();

            if (imageUploaderPlaceholder) imageUploaderPlaceholder.style.display = 'none';
            imagePreviewImage.style.display = 'block';

            reader.addEventListener('load', function () {
                imagePreviewImage.setAttribute('src', this.result);
            });

            reader.readAsDataURL(file);
        } else {
            imagePreviewDefaultText.style.display = null;
            imagePreviewImage.style.display = null;
            imagePreviewImage.setAttribute('src', '');
        }
    });

    // --- Form Submission Logic ---
    createServiceForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const serviceName = document.getElementById('service-name').value;
        const serviceCategory = document.getElementById('service-category').value;
        const serviceNotes = document.getElementById('service-notes').value;
        const priceSmall = document.getElementById('price-small').value;
        const priceMedium = document.getElementById('price-medium').value;
        const priceLarge = document.getElementById('price-large').value;
        const priceXlarge = document.getElementById('price-xlarge').value;
        const isFeatured = document.getElementById('featured-toggle') ? document.getElementById('featured-toggle').checked : false;
        const imageSrc = imagePreviewImage.getAttribute('src');

        // Basic validation
        if (!serviceName || !serviceCategory) {
            alert('Please fill out the Service Name and Category.');
            return;
        }

        const newService = {
            serviceId: `SER-${Date.now().toString().slice(-5)}`, // Generate a semi-unique ID
            service: serviceName,
            category: serviceCategory,
            notes: serviceNotes,
            small: priceSmall || null, // Prices can be edited later on the profile page
            medium: priceMedium || null,
            large: priceLarge || null,
            xLarge: priceXlarge || null,
            featured: isFeatured,
            availability: 'Available',
            imageUrl: imageSrc || null, // Store the Base64 image string
        };

        // Store the new service in sessionStorage to be picked up by the services.js script
        sessionStorage.setItem('newlyCreatedService', JSON.stringify(newService));

        // Redirect back to the services list
        window.location.href = 'services.html';
    });
});