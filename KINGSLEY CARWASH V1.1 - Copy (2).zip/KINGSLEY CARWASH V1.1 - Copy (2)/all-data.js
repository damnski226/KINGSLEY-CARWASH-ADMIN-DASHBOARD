const sampleAppointments = [
    { serviceId: "KC-231001", customer: "Angelo Reyes", phone: "09171234567", plate: "NCP 1234", carName: "Honda Civic", carType: "Sedan", service: "Ceramic Coating", technician: "Bisu Go", status: "Pending", datetime: "Oct 28, 2025 - 2:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231002", customer: "Bea Gonzales", phone: "09182345678", plate: "DAE 5678", carName: "Ford Ranger", carType: "Pickup", service: "Interior Detail (Standard)", technician: "Rey Ignacio", status: "Completed", datetime: "Oct 28, 2025 - 1:30 PM", paymentStatus: "Paid" },
    { serviceId: "KC-231003", customer: "Carlos Mercado", phone: "09193456789", plate: "PQR 9101", carName: "Honda City", carType: "Sedan", service: "Carwash (carwash + armor all)", technician: "Robert Guerrero", status: "In Progress", datetime: "Oct 28, 2025 - 3:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231004", customer: "Sofia Navarro", phone: "09204567890", plate: "XYZ 7890", carName: "Mitsubishi Xpander", carType: "MPV", service: "Carwash (wash + armor all)", technician: "Mike Perez", status: "Completed", datetime: "Oct 28, 2025 - 11:00 AM", paymentStatus: "Paid" },
    { serviceId: "KC-231005", customer: "David Lim", phone: "09215678901", plate: "ABC 1122", carName: "Hyundai Tucson", carType: "SUV", service: "Engine Wash", technician: "JP Gilbuena", status: "Cancelled", datetime: "Oct 28, 2025 - 10:00 AM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231006", customer: "Isabella Garcia", phone: "09226789012", plate: "GHI 3344", carName: "Nissan Terra", carType: "SUV", service: "Full Package Detailing", technician: "Yuan Castillo", status: "Pending", datetime: "Oct 28, 2025 - 4:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231007", customer: "James Fernandez", phone: "09237890123", plate: "JKL 5566", carName: "Toyota Fortuner", carType: "SUV", service: "Carwash (carwash + armor all)", technician: "Jay Ramirez", status: "In Progress", datetime: "Oct 28, 2025 - 3:30 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231008", customer: "Chloe Villanueva", phone: "09258901234", plate: "MNO 7788", carName: "Mazda CX-5", carType: "Crossover", service: "Ceramic Coating", technician: "Ernest Del Mundo", status: "Completed", datetime: "Oct 27, 2025 - 9:00 AM", paymentStatus: "Paid" },
    { serviceId: "KC-231009", customer: "Liam Bautista", phone: "09269012345", plate: "STU 9900", carName: "Geely Coolray", carType: "Crossover", service: "Interior Detail (Standard)", technician: "Bisu Go", status: "Pending", datetime: "Oct 29, 2025 - 9:30 AM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231010", customer: "Andrea Torres", phone: "09270123456", plate: "VWX 1212", carName: "Kia Stonic", carType: "Crossover", service: "Carwash (wash + armor all)", technician: "Rey Ignacio", status: "Completed", datetime: "Oct 27, 2025 - 1:00 PM", paymentStatus: "Paid" },
    { serviceId: "KC-231011", customer: "Lucas Ocampo", phone: "09281234567", plate: "LNA 0001", carName: "Ford Everest", carType: "SUV", service: "Engine Wash", technician: "Robert Guerrero", status: "In Progress", datetime: "Oct 28, 2025 - 1:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231012", customer: "Samantha Ramos", phone: "09292345678", plate: "TMB 1868", carName: "Toyota Raize", carType: "Crossover", service: "Carwash (carwash + armor all)", technician: "Mike Perez", status: "Pending", datetime: "Oct 29, 2025 - 11:00 AM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231013", customer: "Ethan Aquino", phone: "09303456789", plate: "DSL 1763", carName: "MG ZS", carType: "Crossover", service: "Full Package Detailing", technician: "JP Gilbuena", status: "Completed", datetime: "Oct 26, 2025 - 2:00 PM", paymentStatus: "Paid" },
    { serviceId: "KC-231014", customer: "Olivia Cruz", phone: "09314567890", plate: "MHP 1850", carName: "Honda BR-V", carType: "MPV", service: "Ceramic Coating", technician: "Yuan Castillo", status: "Cancelled", datetime: "Oct 26, 2025 - 4:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231015", customer: "Jacob Santos", phone: "09325678901", plate: "GLJ 1856", carName: "Suzuki Ertiga", carType: "MPV", service: "Interior Detail (Standard)", technician: "Jay Ramirez", status: "In Progress", datetime: "Oct 28, 2025 - 5:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231016", customer: "Ava Rodriguez", phone: "09336789012", plate: "PND 1576", carName: "Toyota Wigo", carType: "Hatchback", service: "Carwash (wash + armor all)", technician: "Ernest Del Mundo", status: "Completed", datetime: "Oct 25, 2025 - 10:00 AM", paymentStatus: "Paid" },
    { serviceId: "KC-231017", customer: "Noah Castillo", phone: "09357890123", plate: "RSL 1571", carName: "Mitsubishi Mirage", carType: "Hatchback", service: "Carwash (carwash + armor all)", technician: "Bisu Go", status: "Pending", datetime: "Oct 29, 2025 - 1:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231018", customer: "Mia Flores", phone: "09368901234", plate: "FDG 1744", carName: "Nissan Navara", carType: "Pickup", service: "Engine Wash", technician: "Rey Ignacio", status: "Completed", datetime: "Oct 25, 2025 - 11:00 AM", paymentStatus: "Paid" },
    { serviceId: "KC-231019", customer: "Daniel Mendoza", phone: "09379012345", plate: "SKD 1671", carName: "Isuzu D-Max", carType: "Pickup", service: "Full Package Detailing", technician: "Robert Guerrero", status: "In Progress", datetime: "Oct 28, 2025 - 12:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231020", customer: "Sophia de Leon", phone: "09380123456", plate: "JAS 1942", carName: "Toyota Hilux", carType: "Pickup", service: "Ceramic Coating", technician: "Mike Perez", status: "Pending", datetime: "Oct 29, 2025 - 2:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231021", customer: "Alexander Diaz", phone: "09391234567", plate: "CMR 1890", carName: "Honda HR-V", carType: "Crossover", service: "Interior Detail (Standard)", technician: "JP Gilbuena", status: "Completed", datetime: "Oct 24, 2025 - 3:00 PM", paymentStatus: "Paid" },
    { serviceId: "KC-231022", customer: "Emily Pascual", phone: "09402345678", plate: "MLQ 1935", carName: "Toyota Innova", carType: "MPV", service: "Carwash (carwash + armor all)", technician: "Yuan Castillo", status: "Cancelled", datetime: "Oct 24, 2025 - 1:00 PM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231023", customer: "Benjamin Rivera", phone: "09423456789", plate: "SRG 1944", carName: "Ford Territory", carType: "Crossover", service: "Carwash (wash + armor all)", technician: "Jay Ramirez", status: "In Progress", datetime: "Oct 28, 2025 - 9:00 AM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231024", customer: "Victoria Salazar", phone: "09434567890", plate: "JPL 1943", carName: "Hyundai Creta", carType: "Crossover", service: "Engine Wash", technician: "Ernest Del Mundo", status: "Completed", datetime: "Oct 23, 2025 - 4:00 PM", paymentStatus: "Paid" },
    { serviceId: "KC-231025", customer: "Matthew Jimenez", phone: "09455678901", plate: "MNR 1946", carName: "Kia Seltos", carType: "Crossover", service: "Full Package Detailing", technician: "Bisu Go", status: "Pending", datetime: "Oct 30, 2025 - 10:00 AM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231026", customer: "Natalie Perez", phone: "09466789012", plate: "EPQ 1948", carName: "Chery Tiggo 7", carType: "Crossover", service: "Ceramic Coating", technician: "Rey Ignacio", status: "Completed", datetime: "Oct 23, 2025 - 2:00 PM", paymentStatus: "Paid" },
    { serviceId: "KC-231027", customer: "William Gonzales", phone: "09477890123", plate: "RMG 1953", carName: "Toyota Veloz", carType: "MPV", service: "Interior Detail (Standard)", technician: "Robert Guerrero", status: "In Progress", datetime: "Oct 28, 2025 - 10:30 AM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231028", customer: "Lianne Bautista", phone: "09488901234", plate: "CPG 1957", carName: "Mitsubishi Montero Sport", carType: "SUV", service: "Carwash (carwash + armor all)", technician: "Mike Perez", status: "Pending", datetime: "Oct 30, 2025 - 11:00 AM", paymentStatus: "Unpaid" },
    { serviceId: "KC-231029", customer: "Gabriel Santos", phone: "09499012345", plate: "DMG 1961", carName: "Isuzu mu-X", carType: "SUV", service: "Carwash (wash + armor all)", technician: "JP Gilbuena", status: "Completed", datetime: "Oct 22, 2025 - 1:00 PM", paymentStatus: "Paid" },
    { serviceId: "KC-231030", customer: "Isabelle Dizon", phone: "09500123456", plate: "FMG 1965", carName: "Nissan Kicks", carType: "Crossover", service: "Engine Wash", technician: "Yuan Castillo", status: "Cancelled", datetime: "Oct 22, 2025 - 2:00 PM", paymentStatus: "Unpaid" },
];

const sampleWalkins = [
    { plate: "PWD 123", phone: "09175550001", carName: "Toyota Avanza", carType: "MPV", service: "Carwash (wash + armor all)", technician: "Mike Perez", status: "Completed", paymentStatus: "Paid" },
    { plate: "SNR 456", phone: "09175550002", carName: "Suzuki Jimny", carType: "SUV", service: "Engine Wash", technician: "JP Gilbuena", status: "In Progress", paymentStatus: "Unpaid" },
    { plate: "PWD 789", phone: "09175550003", carName: "Mazda 3", carType: "Sedan", service: "Interior Detail (Standard)", technician: "Yuan Castillo", status: "Pending", paymentStatus: "Unpaid" },
    { plate: "SNR 101", phone: "09175550004", carName: "Subaru Forester", carType: "SUV", service: "Carwash (carwash + armor all)", technician: "Jay Ramirez", status: "Completed", paymentStatus: "Paid" },
    { plate: "PWD 112", phone: "09175550005", carName: "Hyundai Stargazer", carType: "MPV", service: "Carwash (wash + armor all)", technician: "Ernest Del Mundo", status: "Cancelled", paymentStatus: "Unpaid" },
    { plate: "SNR 314", phone: "09175550006", carName: "GAC GS8", carType: "SUV", service: "Engine Wash", technician: "Bisu Go", status: "In Progress", paymentStatus: "Unpaid" },
    { plate: "PWD 159", phone: "09175550007", carName: "Peugeot 2008", carType: "Crossover", service: "Interior Detail (Standard)", technician: "Rey Ignacio", status: "Pending", paymentStatus: "Unpaid" },
    { plate: "SNR 265", phone: "09175550008", carName: "Foton Toplander", carType: "SUV", service: "Carwash (carwash + armor all)", technician: "Robert Guerrero", status: "Completed", paymentStatus: "Paid" },
    { plate: "PWD 358", phone: "09175550009", carName: "Jetour Dashing", carType: "Crossover", service: "Carwash (wash + armor all)", technician: "Mike Perez", status: "In Progress", paymentStatus: "Unpaid" },
    { plate: "SNR 979", phone: "09175550010", carName: "Toyota Wigo", carType: "Hatchback", service: "Engine Wash", technician: "JP Gilbuena", status: "Completed", paymentStatus: "Paid" },
];

const sampleReviews = [
    // Reviews for Bisu Go
    { customer: "Angelo Reyes", service: "Ceramic Coating", rating: 5, comment: "Fantastic job! My car looks brand new. The attention to detail was impeccable.", date: "Oct 28, 2025" },
    { customer: "Liam Bautista", service: "Interior Detailing", rating: 4.5, comment: "Interior is clean and fresh. Great service.", date: "Oct 29, 2025" },
    // Reviews for Rey Ignacio
    { customer: "Bea Gonzales", service: "Interior Detailing", rating: 4, comment: "Very satisfied with the interior cleaning. Missed a small spot under the seat, but overall great work.", date: "Oct 28, 2025" },
    { customer: "Andrea Torres", service: "Basic Wash", rating: 5, comment: "Excellent and fast service. My car is sparkling.", date: "Oct 27, 2025" },
    // Reviews for Robert Guerrero
    { customer: "Carlos Mercado", service: "Premium Wash", rating: 5, comment: "Quick, efficient, and a perfect wash. Will definitely be back.", date: "Oct 28, 2025" },
    // Reviews for Mike Perez
    { customer: "Sofia Navarro", service: "Basic Wash", rating: 4, comment: "Good wash for the price. The team was friendly.", date: "Oct 28, 2025" },
    // Reviews for JP Gilbuena
    { customer: "David Lim", service: "Engine Wash", rating: 5, comment: "The engine bay is spotless. The technicians were very professional and careful.", date: "Oct 28, 2025" },
    // Reviews for Yuan Castillo
    { customer: "Isabella Garcia", service: "Full Detailing", rating: 4.5, comment: "My car feels like it just came out of the showroom. Amazing work!", date: "Oct 28, 2025" },
];

const servicesAndPricing = [
    { serviceId: "SVC-001", category: "Standard", service: "Motorcycle Wash", small: 120, medium: null, large: null, xLarge: 140, notes: "Note: Small is 399cc below, X-Large is 400cc above", availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-002", category: "Standard", service: "Carwash (wash + armor all)", small: 140, medium: 180, large: 220, xLarge: 250, notes: null, availability: "Available", visibility: "Visible", featured: true },
    { serviceId: "SVC-003", category: "Standard", service: "Carwash (carwash + armor all)", small: 240, medium: 280, large: 350, xLarge: 390, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-004", category: "Standard", service: "Engine Wash", small: 600, medium: 700, large: 800, xLarge: 900, notes: null, availability: "Available", visibility: "Visible", featured: true },
    { serviceId: "SVC-005", category: "Standard", service: "Meguiar's Carnauba Wax w/ FREE Carwash", small: 600, medium: 650, large: 700, xLarge: 750, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-006", category: "Standard", service: "Hydrophobic Wax w/ FREE Carwash", small: 700, medium: 750, large: 800, xLarge: 850, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-007", category: "Standard", service: "Double Wax w/ FREE Carwash", small: 1400, medium: 1600, large: 1800, xLarge: 2000, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-008", category: "Standard", service: "Labor Wax", small: 500, medium: 600, large: 700, xLarge: 800, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-009", category: "Standard", service: "Ceiling Cleaning only", small: 1000, medium: 1100, large: 1200, xLarge: 1300, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-010", category: "Standard", service: "Asphalt Removal", small: null, medium: null, large: null, xLarge: null, notes: "5-seater: 250, 7-seater: 350", availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-011", category: "Standard", service: "Seat cover (install)", small: null, medium: null, large: null, xLarge: null, notes: "5-seater: 350, 7-seater: 500", availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-012", category: "Standard", service: "Seat cover (removal)", small: null, medium: null, large: null, xLarge: null, notes: "5-seater: 200, 7-seater: 300", availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-013", category: "Standard", service: "Underwash", small: 600, medium: 700, large: 800, xLarge: 900, notes: "by assessment", availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-014", category: "Standard", service: "MICROTEX BAC TO ZERO (anti-bacterial treatment)", small: 600, medium: 700, large: 800, xLarge: 900, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-015", category: "Detailing", service: "Hydrophobic Protection w/ Carwash", small: 1000, medium: 1200, large: 1400, xLarge: 1600, notes: "up to 6 months Premium Protection", availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-016", category: "Detailing", service: "Ceramic Coating", small: 14000, medium: 18000, large: 22000, xLarge: 26000, notes: "Exterior Detailing included", availability: "Available", visibility: "Visible", featured: true },
    { serviceId: "SVC-017", category: "Detailing", service: "Glass Detailing / Acid Rain", small: null, medium: null, large: null, xLarge: null, notes: "5-seater: 1500, 7-seater: 2000", availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-018", category: "Detailing", service: "Exterior Detailing", small: 4000, medium: 4500, large: 5000, xLarge: 5500, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-019", category: "Detailing", service: "Per Panel Detailing", small: 600, medium: 700, large: 800, xLarge: 900, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-020", category: "Detailing", service: "Interior Detail (Standard)", small: 4500, medium: 5000, large: 5500, xLarge: 6000, notes: null, availability: "Available", visibility: "Visible", featured: true },
    { serviceId: "SVC-021", category: "Detailing", service: "Deep Cleaning", small: null, medium: null, large: null, xLarge: null, notes: "5-seater: 3000, 7-seater: 4000", availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-022", category: "Detailing", service: "Interior Detail + Deep Cleaning", small: 6500, medium: 7000, large: 8500, xLarge: 9000, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-023", category: "Detailing", service: "Full Package Detailing", small: 9500, medium: 10500, large: 11500, xLarge: 12500, notes: null, availability: "Available", visibility: "Visible", featured: false },
    { serviceId: "SVC-024", category: "Detailing", service: "Underseal | Rubberized Coating (3M Undercoat)", small: 4500, medium: 5000, large: 5500, xLarge: 6000, notes: null, availability: "Available", visibility: "Visible", featured: false },
];

const samplePromotions = [
    {
        promoId: "PROMO-001",
        title: "Ultimate Shine Package",
        description: "Get a complete exterior refresh with our most popular services bundled together.",
        services: ["Carwash (wash + armor all)", "Meguiar's Carnauba Wax w/ FREE Carwash"],
        originalPrice: 790, // 140 (small) + 650 (medium) - example
        promoPrice: 650,
        expiryDate: new Date(Date.now() + 10 * 24 * 60 * 60 * 1000).toISOString(), // Expires in 10 days
        imageUrl: "https://images.pexels.com/photos/3729464/pexels-photo-3729464.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", // Shiny red car exterior
        status: "Active"
    },
    {
        promoId: "PROMO-002",
        title: "Interior Revival",
        description: "Deep clean and sanitize your car's interior for a fresh, like-new feel.",
        services: ["Interior Detail (Standard)", "MICROTEX BAC TO ZERO (anti-bacterial treatment)"],
        promoPrice: 4800,
        expiryDate: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(), // Expired 2 days ago
        imageUrl: "https://images.pexels.com/photos/709143/pexels-photo-709143.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1", // Clean car interior
        status: "Expired"
    }
];

// Expose data globally through the appData object for consistent access
window.appData = window.appData || {};
window.appData.appointments = sampleAppointments;
window.appData.walkins = sampleWalkins;
window.appData.reviews = sampleReviews;
window.appData.services = servicesAndPricing;
window.appData.promotions = samplePromotions;

// --- Helper function to create technician dropdowns ---
window.appData.createTechnicianDropdown = (selectedTechnician) => {
    const technicians = window.appData.technicians || [];
    let options = technicians.map(tech => 
        `<option value="${tech.name}" ${tech.name === selectedTechnician ? 'selected' : ''}>${tech.name}</option>`
    ).join('');
    return `<select class="technician-select">${options}</select>`;
};