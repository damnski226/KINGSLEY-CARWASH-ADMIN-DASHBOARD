document.addEventListener('DOMContentLoaded', () => {
    const editServiceForm = document.getElementById('edit-service-form');
    const storedData = sessionStorage.getItem('selectedServiceData');

    if (!editServiceForm || !storedData) {
        alert('Service data not found. Please return to the services list and select a service to edit.');
        window.location.href = 'services.html';
        return;
    }

    const serviceData = JSON.parse(storedData);

    // --- Get Form Elements ---
    const serviceNameInput = document.getElementById('service-name');
    const serviceNotesInput = document.getElementById('service-notes');
    const serviceCategorySelect = document.getElementById('service-category');
    const featuredToggle = document.getElementById('featured-toggle');
    const pricingContainer = document.getElementById('profile-pricing-details');
    const imageInput = document.getElementById('service-image-input');
    const imagePreview = document.getElementById('service-image-preview');
    const imageElement = document.getElementById('profile-service-image');
    const imagePlaceholder = imagePreview.querySelector('.image-uploader-placeholder');

    // --- Populate Form Fields ---
    serviceNameInput.value = serviceData.service;
    serviceNotesInput.value = serviceData.notes || '';

    // Populate Category Dropdown
    const categories = ['Standard', 'Detailing', 'Add-on'];
    categories.forEach(cat => {
        const option = document.createElement('option');
        option.value = cat;
        option.textContent = cat;
        if (cat === serviceData.category) {
            option.selected = true;
        }
        serviceCategorySelect.appendChild(option);
    });

    // Set Featured Toggle
    featuredToggle.checked = serviceData.featured;

    // Populate Pricing Inputs
    pricingContainer.innerHTML = `
        <div class="form-group">
            <label for="price-small">Small</label>
            <input type="number" id="price-small" placeholder="e.g., 150" value="${serviceData.small || ''}">
        </div>
        <div class="form-group">
            <label for="price-medium">Medium</label>
            <input type="number" id="price-medium" placeholder="e.g., 200" value="${serviceData.medium || ''}">
        </div>
        <div class="form-group">
            <label for="price-large">Large</label>
            <input type="number" id="price-large" placeholder="e.g., 250" value="${serviceData.large || ''}">
        </div>
        <div class="form-group">
            <label for="price-xlarge">X-Large</label>
            <input type="number" id="price-xlarge" placeholder="e.g., 300" value="${serviceData.xLarge || ''}">
        </div>
    `;

    // --- Image Update Logic ---
    const renderImage = () => {
        if (serviceData.imageUrl) {
            imageElement.src = serviceData.imageUrl;
            imageElement.style.display = 'block';
            if (imagePlaceholder) imagePlaceholder.style.display = 'none';
        } else {
            imageElement.style.display = 'none';
            if (imagePlaceholder) imagePlaceholder.style.display = 'flex';
        }
    };

    imageInput.addEventListener('change', function() {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                imageElement.src = e.target.result;
                if (imagePlaceholder) imagePlaceholder.style.display = 'none';
                imageElement.style.display = 'block';
            };
            reader.readAsDataURL(file);
        }
    });

    // --- Form Submission (Update) Logic ---
    editServiceForm.addEventListener('submit', (e) => {
        e.preventDefault();

        // Create the updated service object
        const updatedService = {
            ...serviceData, // Keep original ID and other unchanged properties
            service: serviceNameInput.value,
            notes: serviceNotesInput.value,
            category: serviceCategorySelect.value,
            featured: featuredToggle.checked,
            small: parseFloat(document.getElementById('price-small').value) || null,
            medium: parseFloat(document.getElementById('price-medium').value) || null,
            large: parseFloat(document.getElementById('price-large').value) || null,
            xLarge: parseFloat(document.getElementById('price-xlarge').value) || null,
            imageUrl: imageElement.src,
        };

        // Store the updated service to be picked up by the services page
        sessionStorage.setItem('updatedServiceData', JSON.stringify(updatedService));

        // Clean up the edit data
        sessionStorage.removeItem('selectedServiceData');

        // Redirect back to the services list
        window.location.href = 'services.html';
    });

    // --- Populate Analytics ---
    const availedCounts = [...(window.appData.appointments || []), ...(window.appData.walkins || [])].reduce((acc, item) => {
        acc[item.service] = (acc[item.service] || 0) + 1;
        return acc;
    }, {});

    document.getElementById('profile-availed-count').textContent = availedCounts[serviceData.service] || 0;

    // --- Back Button Functionality ---
    const backBtn = document.getElementById('back-btn');
    if (backBtn) {
        backBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.history.back();
        });
    }

    // Initial image render
    renderImage();
});