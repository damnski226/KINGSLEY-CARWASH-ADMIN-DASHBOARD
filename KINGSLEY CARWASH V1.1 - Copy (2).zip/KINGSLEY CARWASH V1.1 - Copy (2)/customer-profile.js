document.addEventListener('DOMContentLoaded', () => {
    // This script runs on the customer-profile.html page

    // Retrieve the stored data from sessionStorage
    const storedData = sessionStorage.getItem('selectedProfileData');

    if (!storedData) {
        // If no data is found, display an error message
        document.getElementById('profile-name').textContent = 'Customer Not Found';
        document.getElementById('profile-plate').textContent = 'Please go back to the appointments page and select a customer.';
        return;
    }

    const appointmentData = JSON.parse(storedData);

    // Now, try to find a matching verified customer from the mobile app data
    const verifiedCustomer = mobileCustomers.find(c => c.plateNumber === appointmentData.plate);

    // Populate the profile page using the appointment data as the primary source,
    // and enhance it with verified data if available.
    document.getElementById('profile-name').textContent = appointmentData.customer || 'Walk-in Customer';
    document.getElementById('profile-plate').textContent = appointmentData.plate || 'N/A';
    document.getElementById('profile-phone').textContent = appointmentData.phone || 'N/A';
    document.getElementById('profile-service').textContent = appointmentData.service || 'N/A';
    document.getElementById('profile-car-name').textContent = appointmentData.carName || 'N/A';
    document.getElementById('overlay-car-type').textContent = appointmentData.carType || 'N/A'; // Corrected ID

    const verificationEl = document.getElementById('profile-verification');
    const verificationText = verificationEl.querySelector('span:last-child');

    if (verifiedCustomer && verifiedCustomer.isVerified) {
        // If a verified customer matches, show their details
        verificationEl.classList.add('verified');
        verificationText.textContent = 'Verified App User';
        document.getElementById('profile-member-since').textContent = verifiedCustomer.registrationDate || 'N/A';
        // Use the verified customer's name if the appointment name was generic
        if (appointmentData.customer === 'Walk-in Customer') {
            document.getElementById('profile-name').textContent = verifiedCustomer.name;
        }
    } else {
        // Otherwise, mark as not verified and use appointment data
        verificationEl.classList.add('unverified');
        verificationText.textContent = 'Not Verified';
        document.getElementById('profile-member-since').textContent = 'N/A';
    }

    // --- Populate Service History ---
    const populateServiceHistory = (plate) => {
        const historyTableBody = document.querySelector('#service-history-table tbody');
        const noHistoryMessage = document.querySelector('.profile-history .no-history');
        if (!historyTableBody || !noHistoryMessage) return;

        // Combine all appointments and walk-ins that match the plate number
        const customerHistory = [
            ...sampleAppointments.filter(appt => appt.plate === plate),
            ...sampleWalkins.filter(walkin => walkin.plate === plate)
        ];

        // Sort by date (this requires parsing the date string, which can be complex. For now, we'll assume string sort is okay)
        // A more robust solution would use a proper date object.
        customerHistory.sort((a, b) => new Date(b.datetime) - new Date(a.datetime));

        if (customerHistory.length === 0) {
            noHistoryMessage.style.display = 'block';
            return;
        }

        const fragment = document.createDocumentFragment();
        customerHistory.forEach(item => {
            const row = document.createElement('tr');
            const statusClass = item.status.toLowerCase().replace(' ', '-');
            row.innerHTML = `
                <td>${item.datetime || 'N/A'}</td>
                <td>${item.service}</td>
                <td>${item.technician}</td>
                <td class="${statusClass} text-center">${item.status}</td>
            `;
            fragment.appendChild(row);
        });
        historyTableBody.appendChild(fragment);
    };

    populateServiceHistory(appointmentData.plate);

    // Clean up the session storage after use to prevent showing stale data
    // if the page is visited directly later.
    // We use a small timeout to ensure any other scripts on the page
    // have a chance to access it if needed.
    setTimeout(() => {
        sessionStorage.removeItem('selectedProfileData');
    }, 500);

    // --- Back Button Functionality ---
    const backBtn = document.getElementById('back-btn');
    if (backBtn) {
        backBtn.addEventListener('click', () => {
            window.history.back();
        });
    }
});