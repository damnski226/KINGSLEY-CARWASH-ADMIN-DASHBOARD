document.addEventListener('DOMContentLoaded', () => {
    const createPromotionForm = document.getElementById('create-promotion-form');
    if (!createPromotionForm) return;

    const imageInput = document.getElementById('promo-image');
    const imagePreview = document.getElementById('image-preview');
    const imagePreviewImage = imagePreview.querySelector('.image-preview-image');
    const imageUploaderPlaceholder = imagePreview.querySelector('.image-uploader-placeholder');
    const serviceChecklist = document.getElementById('service-checklist');

    // --- Populate Service Checklist ---
    const services = window.appData.services || [];
    if (services.length > 0) {
        const fragment = document.createDocumentFragment();
        services.forEach(service => {
            const item = document.createElement('div');
            item.classList.add('checklist-item');
            item.innerHTML = `
                <input type="checkbox" id="service-${service.serviceId}" name="services" value="${service.service}">
                <label for="service-${service.serviceId}">${service.service}</label>
            `;
            fragment.appendChild(item);
        });
        serviceChecklist.appendChild(fragment);
    } else {
        serviceChecklist.innerHTML = '<p class="text-muted">No services found.</p>';
    }

    // --- Image Preview Logic ---
    imageInput.addEventListener('change', function () {
        const file = this.files[0];
        if (file) {
            const reader = new FileReader();
            imageUploaderPlaceholder.style.display = 'none';
            imagePreviewImage.style.display = 'block';
            reader.addEventListener('load', function () {
                imagePreviewImage.setAttribute('src', this.result);
            });
            reader.readAsDataURL(file);
        }
    });

    // --- Form Submission Logic ---
    createPromotionForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const title = document.getElementById('promo-title').value;
        const description = document.getElementById('promo-description').value;
        
        const promoPrices = {
            small: parseFloat(document.getElementById('promo-price-small').value) || null,
            medium: parseFloat(document.getElementById('promo-price-medium').value) || null,
            large: parseFloat(document.getElementById('promo-price-large').value) || null,
            xlarge: parseFloat(document.getElementById('promo-price-xlarge').value) || null,
        };
        const originalPrices = {
            small: parseFloat(document.getElementById('original-price-small').value) || null,
            medium: parseFloat(document.getElementById('original-price-medium').value) || null,
            large: parseFloat(document.getElementById('original-price-large').value) || null,
            xlarge: parseFloat(document.getElementById('original-price-xlarge').value) || null,
        };

        const publishDateInput = document.getElementById('promo-publish-date').value;
        const expiryDateInput = document.getElementById('promo-expiry').value;
        const imageSrc = imagePreviewImage.getAttribute('src');

        // Get selected services
        const selectedServices = [];
        document.querySelectorAll('#service-checklist input[type="checkbox"]:checked').forEach(checkbox => {
            selectedServices.push(checkbox.value);
        });

        // Basic validation
        if (!title || !Object.values(promoPrices).some(p => p) || !publishDateInput || !expiryDateInput || selectedServices.length === 0) {
            alert('Please fill out Title, at least one Promo Price, Publish Date, Expiry Date, and select at least one service.');
            return;
        }

        // Combine date input with current time to create a full ISO string
        const publishDate = new Date(publishDateInput);
        publishDate.setHours(0, 0, 0, 0); // Set to start of the selected day

        const expiryDate = new Date(expiryDateInput);
        expiryDate.setHours(23, 59, 59, 999); // Set to end of the selected day

        const newPromotion = {
            promoId: `PROMO-${Date.now().toString().slice(-5)}`,
            title,
            description,
            services: selectedServices,
            promoPrices,
            originalPrices,
            publishDate: publishDate.toISOString(),
            expiryDate: expiryDate.toISOString(),
            imageUrl: imageSrc || null,
            status: 'Active' // New promos are always active
        };

        // Store the new promotion in sessionStorage
        sessionStorage.setItem('newlyCreatedPromotion', JSON.stringify(newPromotion));

        // Redirect back to the promotions list
        window.location.href = 'promotions.html';
    });

    // Set min date for expiry to today
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('promo-publish-date').setAttribute('min', today);
    document.getElementById('promo-expiry').setAttribute('min', today);
});