document.addEventListener('DOMContentLoaded', () => {
    const sideMenu = document.querySelector('aside');
    const menuBtn = document.querySelector('#menu-btn');
    const closeBtn = document.querySelector('#close-btn');
    const themeToggler = document.querySelector('.theme-toggler');
    const navLinks = document.querySelectorAll('.sidebar-menu a, .profile-dropdown a, .notification-dropdown a');
    const pages = document.querySelectorAll('.page');
    const mainHeaderTitle = document.querySelector('.main-header h1');
    const profile = document.querySelector('.main-header .profile');
    const notificationBell = document.querySelector('.notification-bell');
    let sidebarOverlay;

    // Create and append the sidebar overlay
    const createSidebarOverlay = () => {
        sidebarOverlay = document.createElement('div');
        sidebarOverlay.classList.add('sidebar-overlay');
        document.body.appendChild(sidebarOverlay);
        sidebarOverlay.addEventListener('click', closeSidebar);
    };

    const openSidebar = () => {
        sideMenu.classList.add('show');
        sidebarOverlay.style.display = 'block';
    };

    const closeSidebar = () => {
        sideMenu.classList.remove('show');
        sidebarOverlay.style.display = 'none';
    };

    // --- Sidebar Toggle ---
    if (menuBtn) {
        menuBtn.addEventListener('click', openSidebar);
        closeBtn.addEventListener('click', closeSidebar);
    }

    // --- Theme Toggler ---
    if (themeToggler) {
        themeToggler.addEventListener('click', () => {
            document.body.classList.toggle('dark-theme-variables');
            themeToggler.querySelector('span:nth-child(1)').classList.toggle('active');
            themeToggler.querySelector('span:nth-child(2)').classList.toggle('active');
        });
    }

    // --- Profile Dropdown Toggle ---
    if (profile) {
        const profileDropdown = profile.querySelector('.profile-dropdown');
        const notifDropdown = notificationBell.querySelector('.notification-dropdown');

        profile.addEventListener('click', (e) => {
            // Stop propagation to prevent the window click event from firing immediately
            e.stopPropagation();
            profileDropdown.classList.toggle('show');
            notifDropdown.classList.remove('show'); // Close other dropdown
        });

        // Prevent dropdown from closing when clicking inside it
        profileDropdown.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }

    // --- Notification Dropdown Toggle ---
    if (notificationBell) {
        const notifDropdown = notificationBell.querySelector('.notification-dropdown');
        const profileDropdown = profile.querySelector('.profile-dropdown');

        notificationBell.addEventListener('click', (e) => {
            e.stopPropagation();
            notifDropdown.classList.toggle('show');
            profileDropdown.classList.remove('show'); // Close other dropdown
        });

        // Prevent dropdown from closing when clicking inside it
        notifDropdown.addEventListener('click', (e) => {
            e.stopPropagation();
        });
    }

        // Close dropdown when clicking anywhere else on the page
        window.addEventListener('click', () => {
            const profileDropdown = profile.querySelector('.profile-dropdown');
            const notifDropdown = notificationBell.querySelector('.notification-dropdown');
            if (profileDropdown && profileDropdown.classList.contains('show')) {
                profileDropdown.classList.remove('show');
            }
            if (notifDropdown && notifDropdown.classList.contains('show')) {
                notifDropdown.classList.remove('show');
            }
        });

    // --- Page & Link Navigation ---
    // This logic should only run on the main dashboard page (index.html)
    if (document.getElementById('dashboard')) {
        navLinks.forEach(link => {
            const handleNavClick = (e) => {
                // Allow default for external links like login.html or other pages
                const href = link.getAttribute('href');
                if (href === 'login.html' || (href.includes('.html') && !href.includes('#'))) {
                    return;
                }
    
                if (href.startsWith('#')) {
                    e.preventDefault();
    
                    // Remove active class from all links and pages
                    navLinks.forEach(s_link => {
                        // Only remove 'active' from sidebar links
                        if (s_link.closest('.sidebar-menu')) {
                            s_link.classList.remove('active');
                        }
                    });
                    pages.forEach(page => page.classList.remove('active'));
    
                    // Add active class to the clicked link if it's in the sidebar
                    if (link.closest('.sidebar-menu')) {
                        link.classList.add('active');
                    }
    
                    // Show the corresponding page
                    const targetPageId = href.substring(1);
                    const targetPage = document.getElementById(targetPageId);
                    if (targetPage && mainHeaderTitle) { 
                        targetPage.classList.add('active');
                        // Update header title
                        mainHeaderTitle.textContent = link.querySelector('h3').textContent;
                    }
    
                    // Close sidebar on mobile after clicking a link
                    if (window.innerWidth <= 768) {
                        closeSidebar();
                    }
                }
            };
            link.addEventListener('click', handleNavClick);
        });

        // --- Handle Initial Page Load with Hash ---
        const handleInitialPageLoad = () => {
            const hash = window.location.hash;
            if (hash) {
                // Find the link that points to this hash and simulate a click
                const targetLink = document.querySelector(`.sidebar-menu a[href$="${hash}"]`);
                if (targetLink) {
                    targetLink.click();
                }
            }
        };

        handleInitialPageLoad();
    }

    // --- Animate Insight Cards on Load ---
    const insightCards = document.querySelectorAll('.insights .card');
    const animateInsights = () => {
        insightCards.forEach((card, index) => {
            // Stagger the animation by adding a delay
            card.style.transitionDelay = `${index * 100}ms`;
            card.classList.add('visible');
        });
    };

    // --- Animate Insight Numbers ---
    const animateInsightNumbers = () => {
        const insightNumbers = document.querySelectorAll('.insights .middle h1');
        insightNumbers.forEach(h1 => {
            const targetValue = parseInt(h1.dataset.value);
            const prefix = h1.textContent.startsWith('₱') ? '₱' : '';
            let currentValue = 0;
            const increment = targetValue / 50; // Control animation speed

            const updateCount = () => {
                if (currentValue < targetValue) {
                    currentValue += increment;
                    h1.textContent = prefix + Math.ceil(currentValue).toLocaleString();
                    requestAnimationFrame(updateCount);
                } else {
                    h1.textContent = prefix + targetValue.toLocaleString();
                }
            };

            updateCount();
        });
    };

    // --- Modal Logic ---
    const modalOverlay = document.getElementById('modal-overlay');
    const modal = document.getElementById('app-modal');
    const modalCloseBtn = document.getElementById('modal-close-btn');
    const modalTitle = document.getElementById('modal-title');
    const quickActionButtons = document.querySelectorAll('.quick-actions-card .action-btn');
    const modalContents = document.querySelectorAll('.modal-content');
    const addToDoLink = document.querySelector('.add-item-link');

    // Add event listener for the "Add To-Do" link specifically
    if (addToDoLink) {
        addToDoLink.addEventListener('click', (e) => e.preventDefault());
    }

    // --- Populate Modal Dropdowns ---
    const serviceSelect = document.getElementById('walkin-service');
    if (serviceSelect) {
        const services = window.appData.services || [];
        serviceSelect.innerHTML = '<option value="">Select a service</option>';
        services.forEach(service => {
            const option = document.createElement('option');
            option.value = service.service; // Use the actual service name as the value
            option.textContent = service.service;
            serviceSelect.appendChild(option);
        });
    }

    const openModal = (title, contentId) => {
        modalTitle.textContent = title;

        // Hide all modal content, then show the correct one
        modalContents.forEach(content => content.classList.remove('active'));
        const targetContent = document.getElementById(contentId || 'default-modal-content');
        if (targetContent) {
            targetContent.classList.add('active');
        }

        modalOverlay.classList.add('show');
        document.body.classList.add('modal-open');
    };

    const closeModal = () => {
        modalOverlay.classList.remove('show');
        document.body.classList.remove('modal-open');
        // Deactivate all content for next time
        modalContents.forEach(content => content.classList.remove('active'));
    };

    // This selector now includes all buttons intended to open a modal
    document.querySelectorAll('.action-btn, .add-item-link, .open-modal-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            let title = btn.dataset.modalTitle || 'Quick Action';
            let contentId = btn.dataset.contentId;
            openModal(title, contentId);
        });
    });

    if (modalCloseBtn) {
        modalCloseBtn.addEventListener('click', closeModal);
    }

    if (modalOverlay) {
        modalOverlay.addEventListener('click', (e) => {
            if (e.target === modalOverlay) {
                closeModal();
            }
        });
    }

    // --- Success Toast Notification ---
    const successToast = document.getElementById('success-toast');
    const showSuccessToast = (message) => {
        const toastText = successToast.querySelector('p');
        toastText.textContent = message;
        successToast.classList.add('show');

        setTimeout(() => {
            successToast.classList.remove('show');
        }, 3000); // Hide after 3 seconds
    };

    // --- Reusable Form Validation ---
    const validateForm = (fields, errorMessage) => {
        let isValid = true;

        // Reset all fields first
        fields.forEach(field => field.classList.remove('invalid'));

        // Validation Check
        fields.forEach(field => {
            if (field.value.trim() === '') {
                field.classList.add('invalid');
                isValid = false;
            }
        });

        if (!isValid) {
            alert(errorMessage);
        }

        return isValid;
    };


    // --- Handle Form Submissions ---
    const addPromotionForm = document.getElementById('add-promotion-form');
    if (addPromotionForm) {
        addPromotionForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const promoName = document.getElementById('promo-name');
            const discount = document.getElementById('promo-discount');

            const fieldsToValidate = [promoName, discount];
            if (!validateForm(fieldsToValidate, 'Please fill out all promotion details.')) return;

            const formData = {
                promoName: promoName.value,
                discount: discount.value,
            };

            console.log('New Promotion:', formData);
            showSuccessToast('New promotion created!');
            closeModal();
            addPromotionForm.reset();
        });
    }

    const generateReportForm = document.getElementById('generate-report-form');
    if (generateReportForm) {
        generateReportForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const reportType = document.getElementById('report-type');
            const startDate = document.getElementById('report-start-date');
            const endDate = document.getElementById('report-end-date');

            const fieldsToValidate = [reportType, startDate, endDate];
            if (!validateForm(fieldsToValidate, 'Please select a report type and date range.')) return;

            showSuccessToast(`Generating ${document.getElementById('report-type').value} report...`);
            closeModal();
            generateReportForm.reset();
        });
    }

    const addToDoForm = document.getElementById('add-todo-form');
    if (addToDoForm) {
        addToDoForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const todoTextInput = document.getElementById('todo-text');
            if (!validateForm([todoTextInput], 'Please enter a task description.')) return;
            
            // Create new to-do item element
            const todoItem = document.createElement('div');
            todoItem.classList.add('todo-item', 'new-item');
            todoItem.innerHTML = `
                <div class="icon">
                    <span class="material-symbols-outlined">task</span>
                </div>
                <div class="details">
                    <h3>${todoTextInput.value.trim()}</h3>
                    <small class="text-muted">Just now</small>
                </div>
                <button class="delete-todo-btn">
                    <span class="material-symbols-outlined">delete</span>
                </button>
            `;

            document.querySelector('.todo-list-items').prepend(todoItem);
            showSuccessToast('New to-do item added!');
            closeModal();
            addToDoForm.reset();
        });
    }

    const populateAppointmentsTable = () => {
        // Target only the dashboard's appointment table
        const tableBody = document.querySelector('#dashboard .recent-appointments:not(.walk-in-appointments) tbody');
        if (!tableBody) return;
        const fragment = document.createDocumentFragment();
 
        // Use the global data source from all-data.js
        const appointments = window.appData.appointments || [];

        // Use a slice to show only a subset of recent appointments on the dashboard
        appointments.slice(0, 10).forEach(appt => {
            const row = document.createElement('tr');
            const statusClass = appt.status.toLowerCase().replace(' ', '-');
            row.dataset.customer = appt.customer;
            row.dataset.service = appt.service;
            row.dataset.technician = appt.technician;
            row.dataset.status = appt.status;
            row.dataset.plate = appt.plate;
            row.dataset.datetime = appt.datetime;

            row.innerHTML = `
                <td>${appt.customer}</td>
                <td>${appt.plate}</td>
                <td>${appt.service}</td>
                <td>${appt.technician}</td>
                <td class="text-center"><span class="${statusClass}">${appt.status}</span></td>
            `;
            fragment.appendChild(row);
        });
        tableBody.prepend(fragment);
    };

    const populateWalkinsTable = () => {
        const tableBody = document.querySelector('.walk-in-appointments tbody');
        if (!tableBody) return;
        const fragment = document.createDocumentFragment();
 
        // Use the global data source from all-data.js
        const walkins = window.appData.walkins || [];

        walkins.forEach(walkin => {
            const row = document.createElement('tr');
            const statusClass = walkin.status.toLowerCase().replace(' ', '-');
            row.innerHTML = `
                <td>${walkin.plate}</td>
                <td>${walkin.service}</td>
                <td>${walkin.technician}</td>
                <td class="text-center"><span class="${statusClass}">${walkin.status}</span></td>
            `;
            fragment.appendChild(row);
        });
        tableBody.prepend(fragment);
    };

    const populateServiceReviews = () => {
        const reviewsContainer = document.querySelector('.reviews-container');
        if (!reviewsContainer) return;

        const sampleReviews = window.appData.reviews || [];
        const fragment = document.createDocumentFragment();
        sampleReviews.forEach(review => {
            const reviewCard = document.createElement('div');
            reviewCard.classList.add('review-card');

            let stars = '';
            for (let i = 0; i < 5; i++) {
                stars += `<span class="material-symbols-outlined ${i < review.rating ? 'filled' : ''}">star</span>`;
            }

            reviewCard.innerHTML = `
                <div class="review-header">
                    <div class="review-customer-info">
                        <h3>${review.customer}</h3>
                        <small>${review.service}</small>
                    </div>
                    <div class="review-rating">${stars}</div>
                </div>
                <p class="review-comment">"${review.comment}"</p>
                <small class="review-date text-muted">Reviewed on: ${review.date}</small>
            `;
            fragment.appendChild(reviewCard);
        });
        reviewsContainer.appendChild(fragment);
    };

    // --- Reusable Table Functionality ---
    // Make this function globally available so other scripts can use it
    window.initializeTableFunctionality = (tableContainerSelector) => {
        const tableContainer = document.querySelector(tableContainerSelector);
        if (!tableContainer) return;

        const searchInput = tableContainer.querySelector('input[type="search"]');
        const statusFilter = tableContainer.querySelector('.status-filter');
        const tableBody = tableContainer.querySelector('tbody');
        const noResultsRow = tableContainer.querySelector('.no-results-row');
        const sortableHeaders = tableContainer.querySelectorAll('th[data-sortable="true"]');
        const loader = tableContainer.querySelector('.table-loader');
        const paginationContainer = tableContainer.querySelector('.table-pagination');
        const prevBtn = paginationContainer.querySelector('[data-action="prev"]');
        const nextBtn = paginationContainer.querySelector('[data-action="next"]');
        const pageInfo = paginationContainer.querySelector('.page-info');
        const rowsPerPage = 25; // Show 25 rows per page
        let currentPage = 1;

        // Populate status filter
        // Always ensure the filter is correctly populated, clearing it first.
        if (statusFilter) {
            statusFilter.innerHTML = ''; // Clear existing options to prevent duplicates
            const statuses = ['All Statuses', 'Pending', 'Completed', 'In Progress', 'Cancelled'];
            statuses.forEach(status => {
                const option = document.createElement('option');
                option.value = status === 'All Statuses' ? 'all' : status.toLowerCase();
                option.textContent = status;
                statusFilter.appendChild(option);
            });
            // Set default value
            statusFilter.value = 'all';
        }

        // Filtering and Pagination logic
        const renderTable = () => {
            if (loader) loader.classList.add('loading');

            // Use a timeout to allow the loader to render before the blocking JS runs
            setTimeout(() => {
                const searchTerm = searchInput.value.trim().toLowerCase();
                const selectedStatus = statusFilter ? statusFilter.value : 'all';
                const allRows = Array.from(tableBody.querySelectorAll('tr:not(.no-results-row)'));

                // 1. Filter rows
                const filteredRows = allRows.filter(row => {
                    const rowText = row.textContent.trim().toLowerCase();
                    // Find the status cell by its class, which is more reliable than column index
                    const statusCell = row.querySelector('.pending, .completed, .in-progress, .cancelled');
                    const statusCellText = statusCell ? statusCell.textContent.trim().toLowerCase() : '';

                    const matchesSearch = rowText.includes(searchTerm);
                    const matchesStatus = selectedStatus === 'all' || statusCellText === selectedStatus;
                    return matchesSearch && matchesStatus;
                });

                // 2. Paginate filtered rows
                const totalPages = Math.ceil(filteredRows.length / rowsPerPage);
                currentPage = Math.min(currentPage, totalPages) || 1;

                const startIndex = (currentPage - 1) * rowsPerPage;
                const endIndex = startIndex + rowsPerPage;
                const paginatedRows = filteredRows.slice(startIndex, endIndex);

                // 3. Render the DOM
                allRows.forEach(row => row.style.display = 'none'); // Hide all rows first
                paginatedRows.forEach(row => row.style.display = ''); // Show paginated rows

                // 4. Update UI elements
                if (noResultsRow) {
                    noResultsRow.style.display = filteredRows.length === 0 ? 'table-row' : 'none';
                }

                pageInfo.textContent = `Page ${currentPage} of ${totalPages || 1}`;
                prevBtn.disabled = currentPage === 1;
                nextBtn.disabled = currentPage === totalPages || totalPages === 0;

                if (loader) loader.classList.remove('loading');
            }, 200); // 200ms delay
        };

        // Event Listeners
        searchInput.addEventListener('input', () => {
            currentPage = 1; // Reset to first page on search
            renderTable();
        });
        if (statusFilter) {
            statusFilter.addEventListener('change', () => {
                currentPage = 1; // Reset to first page on filter change
                renderTable();
            });
        }
        prevBtn.addEventListener('click', () => {
            if (currentPage > 1) {
                currentPage--;
                renderTable();
            }
        });
        nextBtn.addEventListener('click', () => {
            currentPage++;
            renderTable();
        });

        // Sorting logic
        sortableHeaders.forEach(header => {
            header.addEventListener('click', () => {
                const columnIndex = Array.from(header.parentElement.children).indexOf(header);
                const currentIsAsc = header.classList.contains('sorted-asc');
                const sortDirection = currentIsAsc ? 'desc' : 'asc';

                tableContainer.querySelectorAll('th').forEach(h => h.classList.remove('sorted-asc', 'sorted-desc'));
                header.classList.add(sortDirection === 'asc' ? 'sorted-asc' : 'sorted-desc');

                const rows = Array.from(tableBody.querySelectorAll('tr:not(.no-results-row)'));
                rows.sort((a, b) => {
                    const aText = a.querySelectorAll('td')[columnIndex].textContent.trim().toLowerCase();
                    const bText = b.querySelectorAll('td')[columnIndex].textContent.trim().toLowerCase();
                    return aText.localeCompare(bText) * (sortDirection === 'asc' ? 1 : -1);
                });
                // Re-append sorted rows to maintain their order in the DOM for filtering
                rows.forEach(row => tableBody.appendChild(row));
                renderTable(); // Re-render the table to apply pagination to the sorted list
            });
        });

        renderTable(); // Initial render
    };

    // --- To-Do List Functionality ---
    const todoListContainer = document.querySelector('.todo-list-items');
    if (todoListContainer) {
        todoListContainer.addEventListener('click', (e) => {
            const todoItem = e.target.closest('.todo-item');
            if (!todoItem) return;

            // Check if delete button was clicked
            if (e.target.closest('.delete-todo-btn')) {
                todoItem.classList.add('removing');
                // Wait for animation to finish before removing from DOM
                todoItem.addEventListener('animationend', () => {
                    todoItem.remove();
                });
            } else {
                // Toggle completed state
                todoItem.classList.toggle('completed');
            }
        });
    }

    // --- Tab Navigation for Reviews Page ---
    const tabNav = document.querySelector('.tab-nav');
    if (tabNav) {
        tabNav.addEventListener('click', (e) => {
            if (e.target.classList.contains('tab-btn')) {
                const tabButtons = tabNav.querySelectorAll('.tab-btn');
                const tabContents = document.querySelectorAll('.tab-content');
                const targetTabContentId = e.target.dataset.tab;

                // Update button active state
                tabButtons.forEach(btn => btn.classList.remove('active'));
                e.target.classList.add('active');

                // Update content active state
                tabContents.forEach(content => {
                    content.classList.remove('active');
                    if (content.id === targetTabContentId) {
                        content.classList.add('active');
                    }
                });
            }
        });
    }

    // --- Sticky Header Shadow on Scroll ---
    const mainHeader = document.querySelector('.main-header');
    if (mainHeader) {
        window.addEventListener('scroll', () => {
            if (window.scrollY > 10) {
                mainHeader.classList.add('scrolled');
            } else {
                mainHeader.classList.remove('scrolled');
            }
        });
    }

    createSidebarOverlay();

    // Run dashboard-specific initializations only if on the dashboard page
    if (document.getElementById('dashboard')) {
        // Initial call to animate the cards
        animateInsights();
        populateAppointmentsTable();
        populateWalkinsTable();
        populateServiceReviews();
        // Initialize dashboard tables only if they exist
        if (document.querySelector('#dashboard .recent-appointments')) {
            initializeTableFunctionality('#dashboard .recent-appointments:not(.walk-in-appointments)');
        }
        initializeTableFunctionality('.walk-in-appointments');
        animateInsightNumbers();
    }
});
