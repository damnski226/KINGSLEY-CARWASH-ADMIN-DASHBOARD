document.addEventListener('DOMContentLoaded', () => {
    const servicesData = window.appData.services || [];

    // --- Check for a newly created service from create-service.html ---
    const newlyCreatedServiceJSON = sessionStorage.getItem('newlyCreatedService');
    if (newlyCreatedServiceJSON) {
        const newService = JSON.parse(newlyCreatedServiceJSON);
        // Add the new service to the top of the data array
        servicesData.unshift(newService);
        // Clean up sessionStorage
        sessionStorage.removeItem('newlyCreatedService');
    }

    // --- Check for an updated service from service-profile.html ---
    const updatedServiceJSON = sessionStorage.getItem('updatedServiceData');
    if (updatedServiceJSON) {
        const updatedService = JSON.parse(updatedServiceJSON);
        const index = servicesData.findIndex(s => s.serviceId === updatedService.serviceId);
        if (index !== -1) {
            servicesData[index] = updatedService; // Replace the old data
        }
        // Clean up sessionStorage
        sessionStorage.removeItem('updatedServiceData');
    }

    const appointmentsData = window.appData.appointments || [];
    const walkinsData = window.appData.walkins || [];
    const servicesTbody = document.getElementById('services-tbody');
    const searchInput = document.getElementById('service-search');
    const categoryFilter = document.getElementById('service-category-filter');
    const deleteSelectedBtn = document.getElementById('delete-selected-services-btn');

    // --- Delete Confirmation Modal Elements ---
    const confirmOverlay = document.getElementById('delete-confirm-overlay');
    const confirmMessage = document.getElementById('delete-confirm-message');
    const confirmBtn = document.getElementById('delete-confirm-btn');
    const cancelBtn = document.getElementById('delete-cancel-btn');
    const closeModalBtn = document.getElementById('delete-confirm-close-btn');
    const successToast = document.getElementById('success-toast');


    if (!servicesTbody) return;

    // --- Calculate how many times each service was availed ---
    const availedCounts = [...appointmentsData, ...walkinsData].reduce((acc, item) => {
        acc[item.service] = (acc[item.service] || 0) + 1;
        return acc;
    }, {});

    const createServiceRow = (service, index) => {
        const row = document.createElement('tr');
        row.dataset.serviceId = service.serviceId;

        // --- Create Specific Price Breakdown ---
        const formatPrice = (price) => price ? `₱${price.toLocaleString()}` : '<span class="text-muted">-</span>';
        const priceBreakdown = `
            <div class="price-breakdown">
                ${service.small ? `<div><small>S:</small> <strong>${formatPrice(service.small)}</strong></div>` : ''}
                ${service.medium ? `<div><small>M:</small> <strong>${formatPrice(service.medium)}</strong></div>` : ''}
                ${service.large ? `<div><small>L:</small> <strong>${formatPrice(service.large)}</strong></div>` : ''}
                ${service.xLarge ? `<div><small>XL:</small> <strong>${formatPrice(service.xLarge)}</strong></div>` : ''}
            </div>
        `;
        // Use notes as fallback if no specific prices exist
        const priceContent = (service.small || service.medium || service.large || service.xLarge) 
            ? priceBreakdown 
            : (service.notes && service.notes.includes(':') ? `<div class="price-notes">${service.notes}</div>` : '<span class="text-muted">—</span>');


        const hasSpecificPrices = service.small || service.medium || service.large || service.xLarge;

        // --- Create Featured Toggle Switch ---
        const featuredToggle = `
            <label class="toggle-switch">
                <input type="checkbox" class="featured-toggle-checkbox" ${service.featured ? 'checked' : ''}>
                <span class="slider"></span>
            </label>
        `;
        
        const statusDropdown = `
            <select class="technician-select status-select ${service.availability.toLowerCase()}">
                <option value="Available" ${service.availability === 'Available' ? 'selected' : ''}>Available</option>
                <option value="Unavailable" ${service.availability === 'Unavailable' ? 'selected' : ''}>Unavailable</option>
            </select>`;

        row.innerHTML = `
            <td><input type="checkbox" class="service-checkbox"></td>
            <td>${service.serviceId}</td>
            <td>
                <div class="service-name-cell">
                    <strong>${service.service}</strong>                    
                    ${!hasSpecificPrices && service.notes ? `<small class="text-muted">${service.notes}</small>` : ''}
                </div>
            </td>
            <td>${priceContent}</td>
            <td>${service.category}</td>
            <td class="text-center">${availedCounts[service.service] || 0}</td>
            <td class="text-center">${featuredToggle}</td>
            <td>${statusDropdown}</td>
            <td class="text-center">
                <button class="action-icon-btn view-service-btn" title="View Service Profile"><span class="material-symbols-outlined">visibility</span></button>
            </td>
        `;
        return row;
    };

    const renderTable = () => {
        const searchTerm = searchInput.value.toLowerCase();
        const selectedCategory = categoryFilter.value;
        
        servicesTbody.innerHTML = ''; // Clear table
        const fragment = document.createDocumentFragment();
        let hasResults = false;

        servicesData.forEach((service, index) => {
            const matchesCategory = selectedCategory === 'all' || service.category === selectedCategory;
            const matchesSearch = service.service.toLowerCase().includes(searchTerm);

            if (matchesCategory && matchesSearch) {
                fragment.appendChild(createServiceRow(service, index));
                hasResults = true;
            }
        });

        const noResultsRow = servicesTbody.nextElementSibling; // Assuming it's immediately after
        if (noResultsRow && noResultsRow.classList.contains('no-results-row')) {
             noResultsRow.style.display = hasResults ? 'none' : 'table-row';
        }

        servicesTbody.appendChild(fragment);
    };

    // --- Event Listeners ---
    if (searchInput) {
        searchInput.addEventListener('input', renderTable);
    }
    if (categoryFilter) {
        categoryFilter.addEventListener('change', renderTable);
    }

    const updateDeleteButtonState = () => {
        const checkedBoxes = servicesTbody.querySelectorAll('.service-checkbox:checked');
        deleteSelectedBtn.disabled = checkedBoxes.length === 0;
    };

    // Handle "Select All" checkbox
    const selectAllCheckbox = document.getElementById('select-all-services');
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', (e) => {
            servicesTbody.querySelectorAll('.service-checkbox').forEach(checkbox => {
                checkbox.checked = e.target.checked;
            });
            updateDeleteButtonState();
        });
    }

    servicesTbody.addEventListener('click', (e) => {
        const viewBtn = e.target.closest('.view-service-btn');
        const featuredToggleInput = e.target.closest('.featured-toggle-checkbox');
        const statusSelect = e.target.closest('.status-select');

        // Handle checkbox clicks for enabling/disabling the delete button
        if (e.target.classList.contains('service-checkbox')) {
            updateDeleteButtonState();
        }

        if (viewBtn) {
            const row = viewBtn.closest('tr');
            const serviceId = row.dataset.serviceId;
            const service = servicesData.find(s => s.serviceId === serviceId);

            if (service) {
                sessionStorage.setItem('selectedServiceData', JSON.stringify(service));
                window.location.href = 'service-profile.html';
            }
            return;
        }

        if (featuredToggleInput) {
            const row = featuredToggleInput.closest('tr');
            const serviceId = row.dataset.serviceId;
            const service = servicesData.find(s => s.serviceId === serviceId);

            if (service) {
                // Update the data model
                service.featured = featuredToggleInput.checked;

                // Show a success message
                const message = service.featured 
                    ? `"${service.service}" is now featured.`
                    : `"${service.service}" is no longer featured.`;
                showSuccessToast(message);
            }
        }
    });

    servicesTbody.addEventListener('change', (e) => {
        const statusSelect = e.target.closest('.status-select');
        if (statusSelect) {
            const row = statusSelect.closest('tr');
            const serviceId = row.dataset.serviceId;
            const service = servicesData.find(s => s.serviceId === serviceId);
            const newStatus = statusSelect.value;

            if (service) {
                // Update the data model
                service.availability = newStatus;

                // Update the dropdown's class to change its color
                statusSelect.className = `technician-select status-select ${newStatus.toLowerCase()}`;

                // Show a success message
                const message = `"${service.service}" status updated to ${newStatus}.`;
                showSuccessToast(message);
            }
        }
    });

    deleteSelectedBtn.addEventListener('click', () => {
        const checkedBoxes = servicesTbody.querySelectorAll('.service-checkbox:checked');
        const count = checkedBoxes.length;
        if (count > 0) {
            openDeleteConfirmModal(count, () => {
                const idsToDelete = Array.from(checkedBoxes).map(cb => cb.closest('tr').dataset.serviceId);
                deleteServices(idsToDelete);
            });
        }
    });

    // --- Delete Modal Logic ---
    const openDeleteConfirmModal = (count, confirmCallback) => {
        if (!confirmOverlay) return;
        confirmMessage.innerHTML = `Are you sure you want to delete <strong>${count} service(s)</strong>? This action cannot be undone.`;
        confirmOverlay.classList.add('show');

        // Use { once: true } to avoid attaching multiple listeners
        confirmBtn.addEventListener('click', function handler() {
            confirmCallback();
            closeDeleteConfirmModal();
            confirmBtn.removeEventListener('click', handler);
        }, { once: true });
    };

    const closeDeleteConfirmModal = () => {
        if (confirmOverlay) confirmOverlay.classList.remove('show');
    };

    const deleteServices = (serviceIds) => {
        let deletedCount = 0;
        serviceIds.forEach(id => {
            const serviceIndex = servicesData.findIndex(s => s.serviceId === id);
            if (serviceIndex > -1) {
                servicesData.splice(serviceIndex, 1);
                deletedCount++;
            }
        });
        if (deletedCount > 0) {
            renderTable();
            updateDeleteButtonState();
            showSuccessToast(`${deletedCount} service(s) deleted successfully!`);
        }
    };

    // --- Success Toast Notification ---
    const showSuccessToast = (message) => {
        if (!successToast) return;
        const toastText = successToast.querySelector('p');
        toastText.textContent = message;
        successToast.classList.add('show');

        setTimeout(() => {
            successToast.classList.remove('show');
        }, 3000); // Hide after 3 seconds
    };
    
    if (cancelBtn) cancelBtn.addEventListener('click', closeDeleteConfirmModal);
    if (closeModalBtn) closeModalBtn.addEventListener('click', closeDeleteConfirmModal);
    if (confirmOverlay) confirmOverlay.addEventListener('click', (e) => { if (e.target === confirmOverlay) closeDeleteConfirmModal(); });

    // Initial render
    renderTable();
});
