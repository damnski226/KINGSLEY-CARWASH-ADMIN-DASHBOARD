document.addEventListener('DOMContentLoaded', () => {
    const promotionsCarousel = document.getElementById('promotions-carousel');
    const promotionsTbody = document.getElementById('promotions-tbody');
    if (!promotionsCarousel || !promotionsTbody) return;

    const promotionsData = window.appData.promotions || [];

    // Check for a newly created promotion
    const newPromoJSON = sessionStorage.getItem('newlyCreatedPromotion');
    if (newPromoJSON) {
        const newPromo = JSON.parse(newPromoJSON);
        promotionsData.unshift(newPromo);
        sessionStorage.removeItem('newlyCreatedPromotion');
    }

    // Check for an updated promotion
    const updatedPromoJSON = sessionStorage.getItem('updatedPromotion');
    if (updatedPromoJSON) {
        const updatedPromo = JSON.parse(updatedPromoJSON);
        const index = promotionsData.findIndex(p => p.promoId === updatedPromo.promoId);
        if (index !== -1) {
            promotionsData[index] = updatedPromo; // Replace the old data
        }
        // Clean up sessionStorage
        sessionStorage.removeItem('updatedPromotion');
    }

    const createPromotionCarouselCard = (promo) => {
        const card = document.createElement('div');
        card.classList.add('promotion-card');

        const now = new Date();
        const expiryDate = new Date(promo.expiryDate);
        const isExpired = now > expiryDate;
        const status = isExpired ? 'Expired' : 'Active';

        card.classList.toggle('expired', isExpired);

        // --- Price Range Logic ---
        const getPriceRange = (prices) => {
            if (!prices) return '';
            const validPrices = Object.values(prices).filter(p => p !== null);
            if (validPrices.length === 0) return '';
            if (validPrices.length === 1) return `₱${validPrices[0].toLocaleString()}`;
            
            const minPrice = Math.min(...validPrices);
            const maxPrice = Math.max(...validPrices);

            if (minPrice === maxPrice) return `₱${minPrice.toLocaleString()}`;
            return `₱${minPrice.toLocaleString()} - ₱${maxPrice.toLocaleString()}`;
        };

        const promoPriceDisplay = getPriceRange(promo.promoPrices) || `₱${promo.promoPrice?.toLocaleString() || 'N/A'}`; // Fallback for old data
        const originalPriceDisplay = getPriceRange(promo.originalPrices) || (promo.originalPrice ? `₱${promo.originalPrice.toLocaleString()}` : '');

        const originalPriceHTML = originalPriceDisplay ? `<del>${originalPriceDisplay}</del>` : '';


        card.innerHTML = `
            <div class="promo-card-image" style="height: 120px;">
                <img src="${promo.imageUrl || 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'}" alt="${promo.title}">
                <span class="promo-status-badge ${status.toLowerCase()}">${status}</span>
            </div>
            <div class="promo-card-content">
                <h3>${promo.title}</h3>
                <p>${promo.description}</p>
                <div class="promo-pricing">
                    <span class="promo-price">${promoPriceDisplay}</span>
                    ${originalPriceHTML}
                </div>
            </div>
            <div class="promo-card-footer">
                <div class="promo-countdown" data-expiry="${promo.expiryDate}">
                    <div class="countdown-item">
                        <span class="countdown-value" data-unit="days">00</span>
                        <span class="countdown-label">Days</span>
                    </div>
                    <div class="countdown-item">
                        <span class="countdown-value" data-unit="hours">00</span>
                        <span class="countdown-label">Hours</span>
                    </div>
                    <div class="countdown-item">
                        <span class="countdown-value" data-unit="minutes">00</span>
                        <span class="countdown-label">Mins</span>
                    </div>
                    <div class="countdown-item">
                        <span class="countdown-value" data-unit="seconds">00</span>
                        <span class="countdown-label">Secs</span>
                    </div>
                </div>
            </div>
        `;
        return card;
    };

    const createPromotionTableRow = (promo) => {
        const row = document.createElement('tr');
        row.dataset.promoId = promo.promoId; // Add promoId to the row for easy lookup
        const publishDate = new Date(promo.publishDate);
        const expiryDate = new Date(promo.expiryDate);
        const options = { month: 'short', day: 'numeric', year: 'numeric' };
        const formattedPublishDate = publishDate.toLocaleDateString('en-US', options);
        const formattedExpiryDate = expiryDate.toLocaleDateString('en-US', options);

        // --- Price Range Logic for Table ---
        const getPriceRange = (prices) => {
            if (!prices) return '';
            const validPrices = Object.values(prices).filter(p => p !== null);
            if (validPrices.length === 0) return '';
            if (validPrices.length === 1) return `₱${validPrices[0].toLocaleString()}`;
            
            const minPrice = Math.min(...validPrices);
            const maxPrice = Math.max(...validPrices);

            if (minPrice === maxPrice) return `₱${minPrice.toLocaleString()}`;
            return `₱${minPrice.toLocaleString()} - ₱${maxPrice.toLocaleString()}`;
        };

        const promoPriceDisplay = getPriceRange(promo.promoPrices) || `₱${promo.promoPrice?.toLocaleString() || 'N/A'}`;
        const originalPriceDisplay = getPriceRange(promo.originalPrices) || (promo.originalPrice ? `₱${promo.originalPrice.toLocaleString()}` : '');

        const includedServicesHTML = promo.services.map(s => `<li>${s}</li>`).join('');
        const originalPriceHTML = originalPriceDisplay ? `<del>${originalPriceDisplay}</del>` : '';

        row.innerHTML = `
            <td><input type="checkbox" class="promo-checkbox"></td>
            <td>
                <div class="promo-banner-cell">
                    <img src="${promo.imageUrl || 'https://images.pexels.com/photos/170811/pexels-photo-170811.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'}" alt="${promo.title}">
                </div>
            </td>
            <td>
                <div class="promo-details-cell">
                    <strong>${promo.title}</strong>
                    <ul>${includedServicesHTML}</ul>
                </div>
            </td>
            <td>
                <div class="promo-pricing-cell">
                    <span class="promo-price">${promoPriceDisplay}</span>
                    ${originalPriceHTML}
                </div>
            </td>
            <td>${formattedPublishDate}</td>
            <td>${formattedExpiryDate}</td>
            <td class="text-center">
                <button class="action-icon-btn edit-promo-btn" title="Edit Promotion"><span class="material-symbols-outlined">edit</span></button>
                <button class="action-icon-btn delete-promo-btn" title="Delete Promotion"><span class="material-symbols-outlined">delete</span></button>
            </td>
        `;
        return row;
    };

    const renderPromotions = () => {
        promotionsCarousel.innerHTML = '';
        promotionsTbody.innerHTML = '';

        promotionsData.forEach(promo => {
            // Add active promos to carousel
            if (new Date() < new Date(promo.expiryDate)) {
                promotionsCarousel.appendChild(createPromotionCarouselCard(promo));
            }
            // Add all promos to table
            promotionsTbody.appendChild(createPromotionTableRow(promo));
        });
    };

    const updateCountdowns = () => {
        const countdownElements = promotionsCarousel.querySelectorAll('.promo-countdown');
        countdownElements.forEach(el => {
            const expiryDate = new Date(el.dataset.expiry);
            const now = new Date();
            const diff = expiryDate - now;

            if (diff <= 0) {
                el.innerHTML = '<div class="countdown-expired">This promotion has expired.</div>';
                return;
            }

            const days = Math.floor(diff / (1000 * 60 * 60 * 24));
            const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
            const minutes = Math.floor((diff / 1000 / 60) % 60);
            const seconds = Math.floor((diff / 1000) % 60);

            el.querySelector('[data-unit="days"]').textContent = String(days).padStart(2, '0');
            el.querySelector('[data-unit="hours"]').textContent = String(hours).padStart(2, '0');
            el.querySelector('[data-unit="minutes"]').textContent = String(minutes).padStart(2, '0');
            el.querySelector('[data-unit="seconds"]').textContent = String(seconds).padStart(2, '0');
        });
    };

    // Initial Render
    renderPromotions();
    updateCountdowns();

    // Update countdowns every second
    setInterval(updateCountdowns, 1000);

    // --- Action Button Event Listeners ---
    promotionsTbody.addEventListener('click', (e) => {
        const editBtn = e.target.closest('.edit-promo-btn');
        if (editBtn) {
            const row = editBtn.closest('tr');
            const promoId = row.dataset.promoId;
            const promoToEdit = promotionsData.find(p => p.promoId === promoId);

            if (promoToEdit) {
                sessionStorage.setItem('promotionToEdit', JSON.stringify(promoToEdit));
                window.location.href = 'edit-promotion.html';
            }
        }
        // Add delete logic here in the future if needed
    });
});