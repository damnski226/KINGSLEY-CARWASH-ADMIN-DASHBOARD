document.addEventListener('DOMContentLoaded', () => {
    // This script is now for the main appointments page
    const mainAppointmentsContainer = document.getElementById('main-appointments-table');

    if (mainAppointmentsContainer) {
        // --- Data for the main appointments table ---
        // --- Animate Insight Numbers ---
        const animateInsightNumbers = (element, isIncrement = false) => {
            const targetValue = parseInt(element.dataset.value);
            const prefix = element.textContent.startsWith('₱') ? '₱' : '';
            
            if (isIncrement) {
                // Simple increment, no complex animation needed
                element.textContent = prefix + targetValue.toLocaleString();
                return;
            }

            let currentValue = 0;
            const increment = targetValue / 50; // Control animation speed

            const updateCount = () => {
                if (currentValue < targetValue) {
                    currentValue += increment;
                    element.textContent = prefix + Math.ceil(currentValue).toLocaleString();
                    requestAnimationFrame(updateCount);
                } else {
                    element.textContent = prefix + targetValue.toLocaleString();
                }
            };
            updateCount();
        };

        // --- Update Appointment Widgets ---
        const updateAppointmentWidgets = (isIncrement = false) => {
            const totalEl = document.getElementById('total-appointments-count');
            const pendingEl = document.getElementById('pending-appointments-count');
            const completedEl = document.getElementById('completed-appointments-count');
            const cancelledEl = document.getElementById('cancelled-appointments-count');

            if (!totalEl || !pendingEl || !completedEl || !cancelledEl) return;

            const counts = sampleAppointments.reduce((acc, appt) => {
                acc.total++;
                const status = appt.status.toLowerCase();
                if (status === 'pending') acc.pending++;
                if (status === 'completed') acc.completed++;
                if (status === 'cancelled') acc.cancelled++;
                return acc;
            }, { total: 0, pending: 0, completed: 0, cancelled: 0 });

            totalEl.dataset.value = counts.total;
            pendingEl.dataset.value = counts.pending;

            animateInsightNumbers(totalEl, isIncrement);
            animateInsightNumbers(pendingEl, isIncrement);

            // Only animate these on initial load
            if (!isIncrement) {
                completedEl.dataset.value = counts.completed;
                cancelledEl.dataset.value = counts.cancelled;
                animateInsightNumbers(completedEl);
                animateInsightNumbers(cancelledEl);
            }
        };

        // --- Populate Table ---
        const populateAppointmentsTable = () => {
            const tableBody = mainAppointmentsContainer.querySelector('tbody');
            if (!tableBody) return;
            const fragment = document.createDocumentFragment();

            sampleAppointments.forEach(appt => {
                const row = document.createElement('tr');
                const statusClass = appt.status.toLowerCase().replace(' ', '-');
                // Add data attributes for modal functionality if needed later
                row.dataset.serviceId = appt.serviceId;
                row.dataset.customer = appt.customer;
                row.dataset.phone = appt.phone;
                row.dataset.service = appt.service;
                row.dataset.technician = appt.technician;
                row.dataset.status = appt.status;
                row.dataset.plate = appt.plate;
                row.dataset.carName = appt.carName;
                row.dataset.carType = appt.carType;
                row.dataset.paymentStatus = appt.paymentStatus;
                row.dataset.datetime = appt.datetime;

                // Conditionally add action buttons based on status
                let actionButtons = '';
                if (appt.status === 'Pending') {
                    actionButtons = `
                        <button class="action-icon-btn start-service-btn" title="Start Service">
                            <span class="material-symbols-outlined">play_arrow</span>
                        </button>`;
                } else if (appt.status === 'In Progress') {
                    actionButtons = `
                        <button class="action-icon-btn complete-service-btn" title="Complete Service">
                            <span class="material-symbols-outlined">check</span>
                        </button>`;
                }

                const technicianDropdown = window.appData.createTechnicianDropdown(appt.technician);

                const paymentStatusClass = appt.paymentStatus.toLowerCase();
                const paymentBadge = `<span class="payment-status-badge ${paymentStatusClass}">${appt.paymentStatus}</span>`;

                let paymentActionButton = '';
                if (appt.paymentStatus === 'Unpaid') {
                    paymentActionButton = `
                        <button class="action-icon-btn mark-paid-btn" title="Mark as Paid">
                            <span class="material-symbols-outlined">payments</span>
                        </button>`;
                }
                row.innerHTML = `
                    <td>${appt.serviceId}</td>
                    <td>${appt.customer}</td>
                    <td>${appt.phone}</td>
                    <td>${appt.plate}</td>
                    <td>${appt.carName}</td>
                    <td>${appt.carType}</td>
                    <td>${appt.service}</td>
                    <td>${technicianDropdown}</td>
                    <td class="text-center"><span class="${statusClass}">${appt.status}</span></td>
                    <td class="text-center">${paymentBadge}</td>
                    <td class="text-center">
                        ${actionButtons}
                        ${paymentActionButton}
                        <button class="action-icon-btn cancel-btn" title="Cancel Appointment">
                            <span class="material-symbols-outlined">cancel</span>
                        </button>
                    </td>
                `;
                fragment.appendChild(row);
            });
            // Prepend to keep the 'no-results-row' at the end
            tableBody.prepend(fragment);
        };

        // --- Add a single appointment to the top of the table ---
        const addAppointmentToTable = (appt) => {
            const tableBody = mainAppointmentsContainer.querySelector('tbody');
            if (!tableBody) return;

            const row = document.createElement('tr');
            const statusClass = appt.status.toLowerCase().replace(' ', '-');
            row.dataset.customer = appt.customer;
            row.dataset.phone = appt.phone;
            row.dataset.service = appt.service;
            row.dataset.technician = appt.technician;
            row.dataset.status = appt.status;
            row.dataset.plate = appt.plate;
            row.dataset.carName = appt.carName;
            row.dataset.carType = appt.carType;
            row.dataset.datetime = appt.datetime;

            let actionButtons = '';
            if (appt.status === 'Pending') {
                actionButtons = `
                    <button class="action-icon-btn start-service-btn" title="Start Service">
                        <span class="material-symbols-outlined">play_arrow</span>
                    </button>`;
            } else if (appt.status === 'In Progress') {
                // This case is less likely for a new item, but good for consistency
            }

            row.innerHTML = `
                <td>${appt.customer}</td>
                <td>${appt.phone}</td>
                <td>${appt.plate}</td>
                <td>${appt.carName}</td>
                <td>${appt.carType}</td>
                <td>${appt.service}</td>
                <td>${appt.technician}</td>
                <td class="text-center"><span class="${statusClass}">${appt.status}</span></td>
                <td class="text-center">
                    ${actionButtons}
                    <button class="action-icon-btn cancel-btn" title="Cancel Appointment">
                        <span class="material-symbols-outlined">cancel</span>
                    </button>
                </td>
            `;
            tableBody.prepend(row);
        }

        // --- Populate Walk-ins Table ---
        const populateWalkinsTable = () => {
            const tableBody = mainAppointmentsContainer.parentElement.querySelector('#walk-in-appointments-table tbody');
            if (!tableBody) return;
            const fragment = document.createDocumentFragment();
    
            sampleWalkins.forEach(walkin => {
                const row = document.createElement('tr');
                const statusClass = walkin.status.toLowerCase().replace(' ', '-');
                // Add data attributes for modal functionality
                row.dataset.plate = walkin.plate;
                row.dataset.phone = walkin.phone;
                row.dataset.service = walkin.service;
                row.dataset.technician = walkin.technician;
                row.dataset.status = walkin.status;
                row.dataset.carName = walkin.carName;
                row.dataset.carType = walkin.carType;
                row.dataset.paymentStatus = walkin.paymentStatus;

                let actionButtons = '';
                if (walkin.status === 'Pending') {
                    actionButtons = `
                        <button class="action-icon-btn start-service-btn" title="Start Service">
                            <span class="material-symbols-outlined">play_arrow</span>
                        </button>`;
                } else if (walkin.status === 'In Progress') {
                    actionButtons = `
                        <button class="action-icon-btn complete-service-btn" title="Complete Service">
                            <span class="material-symbols-outlined">check</span>
                        </button>`;
                }

                const technicianDropdown = window.appData.createTechnicianDropdown(walkin.technician);

                const paymentStatusClass = walkin.paymentStatus.toLowerCase();
                const paymentBadge = `<span class="payment-status-badge ${paymentStatusClass}">${walkin.paymentStatus}</span>`;

                let paymentActionButton = '';
                if (walkin.paymentStatus === 'Unpaid') {
                    paymentActionButton = `
                        <button class="action-icon-btn mark-paid-btn" title="Mark as Paid">
                            <span class="material-symbols-outlined">payments</span>
                        </button>`;
                }
                row.innerHTML = `
                    <td>${walkin.plate}</td>
                    <td>${walkin.phone}</td>
                    <td>${walkin.carName}</td>
                    <td>${walkin.carType}</td>
                    <td>${walkin.service}</td>
                    <td>${technicianDropdown}</td>
                    <td class="text-center"><span class="${statusClass}">${walkin.status}</span></td>
                    <td class="text-center">${paymentBadge}</td>
                    <td class="text-center">
                        ${actionButtons}
                        ${paymentActionButton}
                        <button class="action-icon-btn cancel-btn" title="Cancel Appointment">
                            <span class="material-symbols-outlined">cancel</span>
                        </button>
                    </td>
                `;
                fragment.appendChild(row);
            });
            tableBody.prepend(fragment);
        };

        // --- Add a single walk-in to the top of the table ---
        const addWalkinToTable = (walkin) => {
            const tableBody = document.querySelector('#walk-in-appointments-table tbody');
            if (!tableBody) return;

            const row = document.createElement('tr');
            const statusClass = walkin.status.toLowerCase().replace(' ', '-');
            row.dataset.plate = walkin.plate;
            row.dataset.phone = walkin.phone;
            row.dataset.service = walkin.service;
            row.dataset.technician = walkin.technician;
            row.dataset.status = walkin.status;
            row.dataset.carName = walkin.carName;
            row.dataset.carType = walkin.carType;
            row.dataset.paymentStatus = walkin.paymentStatus;

            const technicianDropdown = window.appData.createTechnicianDropdown(walkin.technician);
            const paymentBadge = `<span class="payment-status-badge unpaid">Unpaid</span>`;
            const paymentActionButton = `
                <button class="action-icon-btn mark-paid-btn" title="Mark as Paid">
                    <span class="material-symbols-outlined">payments</span>
                </button>`;
            const actionButtons = `
                <button class="action-icon-btn start-service-btn" title="Start Service">
                    <span class="material-symbols-outlined">play_arrow</span>
                </button>`;

            row.innerHTML = `
                <td>${walkin.plate}</td>
                <td>${walkin.phone}</td>
                <td>${walkin.carName}</td>
                <td>${walkin.carType}</td>
                <td>${walkin.service}</td>
                <td>${technicianDropdown}</td>
                <td class="text-center"><span class="${statusClass}">${walkin.status}</span></td>
                <td class="text-center">${paymentBadge}</td>
                <td class="text-center">${actionButtons} ${paymentActionButton} <button class="action-icon-btn cancel-btn" title="Cancel Appointment"><span class="material-symbols-outlined">cancel</span></button></td>
            `;
            tableBody.prepend(row);
        };

        // --- Open Appointment Details Modal on Row Click ---
        const appointmentTableBody = mainAppointmentsContainer.querySelector('tbody');
        if (appointmentTableBody) {
            appointmentTableBody.addEventListener('click', (e) => {
                const cancelButton = e.target.closest('.cancel-btn');
                const startServiceButton = e.target.closest('.start-service-btn');
                const completeServiceButton = e.target.closest('.complete-service-btn');
                const markPaidButton = e.target.closest('.mark-paid-btn');
                const technicianSelect = e.target.closest('.technician-select');
                const row = e.target.closest('tr');

                if (!row || row.classList.contains('no-results-row')) return;

                if (startServiceButton) {
                    const appointment = sampleAppointments.find(a => a.plate === row.dataset.plate && a.customer === row.dataset.customer);
                    if (appointment && appointment.status === 'Pending') {
                        const startTime = new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }); // prettier-ignore
                        appointment.status = 'In Progress';
                        appointment.startTime = startTime;
                        row.dataset.status = 'In Progress';
                        row.dataset.startTime = startTime;
                        const statusCell = row.querySelector('td:nth-last-child(3)'); // The 3rd cell from the end is Status
                        statusCell.innerHTML = `<span class="in-progress">In Progress</span>`;

                        // Show success toast
                        if (typeof showSuccessToast === 'function') showSuccessToast(`Service for ${appointment.customer} has started.`);

                        // Replace the start button with a complete button
                        const actionsCell = startServiceButton.parentElement;
                        startServiceButton.remove();
                        actionsCell.insertAdjacentHTML('afterbegin', `
                            <button class="action-icon-btn complete-service-btn" title="Complete Service">
                                <span class="material-symbols-outlined">check</span>
                            </button>
                        `);
                    }
                    return;
                }

                if (completeServiceButton) {
                    const appointment = sampleAppointments.find(a => a.plate === row.dataset.plate && a.customer === row.dataset.customer);
                    if (appointment && appointment.status === 'In Progress') {
                        appointment.status = 'Completed';
                        row.dataset.status = 'Completed';
                        const statusCell = row.querySelector('td:nth-last-child(3)'); // The 3rd cell from the end is Status
                        statusCell.innerHTML = `<span class="completed">Completed</span>`;

                        if (typeof showSuccessToast === 'function') showSuccessToast(`Service for ${appointment.customer} is complete.`);
                        completeServiceButton.remove();
                    }
                    return;
                }

                if (cancelButton) {
                    // Find the appointment in the data array and update its status
                    const appointment = sampleAppointments.find(a => a.plate === row.dataset.plate && a.customer === row.dataset.customer);
                    if (appointment) {
                        appointment.status = 'Cancelled';
                        row.dataset.status = 'Cancelled';
                        const statusCell = row.querySelector('td:nth-last-child(3)'); // The 3rd cell from the end is Status
                        statusCell.innerHTML = `<span class="cancelled">Cancelled</span>`;
                        // Optionally, disable the cancel button after clicking
                        cancelButton.disabled = true;
                        // Re-render the table to reflect filter/sort changes if needed
                        initializeTableFunctionality('#main-appointments-table');
                        // Re-initialize the global function from script.js
                        if (typeof window.initializeTableFunctionality === 'function') window.initializeTableFunctionality('#main-appointments-table');
                    } 
                    return;
                }

                if (markPaidButton) {
                    const appointment = sampleAppointments.find(a => a.serviceId === row.dataset.serviceId);
                    if (appointment && appointment.paymentStatus === 'Unpaid') {
                        appointment.paymentStatus = 'Paid';
                        row.dataset.paymentStatus = 'Paid';

                        const paymentCell = row.querySelector('td:nth-last-child(2)');
                        paymentCell.innerHTML = `<span class="payment-status-badge paid">Paid</span>`;

                        if (typeof showSuccessToast === 'function') showSuccessToast(`Appointment ${appointment.serviceId} marked as paid.`);
                        
                        // Remove the button after it's clicked
                        markPaidButton.remove();
                    }
                    return;
                }

                // If the click was on the row itself (but not on a button), show details overlay
                const isActionButtonClick = startServiceButton || completeServiceButton || cancelButton || markPaidButton || technicianSelect;
                if (!isActionButtonClick) {
                    const appointment = sampleAppointments.find(a => a.plate === row.dataset.plate && a.customer === row.dataset.customer);
                    if (appointment) {
                        // Store the selected appointment data and navigate
                        sessionStorage.setItem('selectedProfileData', JSON.stringify(appointment));
                        window.location.href = `customer-profile.html`;
                    }
                }

            });
        }

        // --- Handle New Appointment Form Submission ---
        const newAppointmentForm = document.getElementById('new-walk-in-form');
        if (newAppointmentForm) {
            // Use a named function to avoid attaching multiple listeners if script runs again
            const handleAppointmentSubmit = (e) => {
                e.preventDefault();
                const customerName = document.getElementById('walkin-customer-name');
                const customerPhone = document.getElementById('walkin-customer-phone');
                const plateNumber = document.getElementById('walkin-car-plate');
                const serviceSelect = document.getElementById('walkin-service');
                const carName = document.getElementById('walkin-car-name');
                const carType = document.getElementById('walkin-car-type');

                // This validation function is in script.js, so we check if it exists
                if (typeof validateForm === 'function' && !validateForm([customerName, customerPhone, plateNumber, serviceSelect], 'Please fill out all required fields.')) {
                    return;
                }

                const newWalkin = {
                    // customer: customerName.value.trim(), // Walk-ins don't have a customer name field in the table
                    phone: customerPhone.value.trim(),
                    plate: plateNumber.value.trim().toUpperCase(),
                    carName: carName.value.trim() || 'N/A',
                    carType: carType.value.trim() || 'N/A',
                    service: serviceSelect.options[serviceSelect.selectedIndex].text,
                    technician: "Unassigned", // Default value for new appointments
                    paymentStatus: "Unpaid", // Default for new walk-ins
                    status: "Pending",       // New walk-ins are always Pending
                };

                sampleWalkins.unshift(newWalkin); // Add to the walk-in data array
                addWalkinToTable(newWalkin);
                // updateAppointmentWidgets(true); // This is not needed for walk-ins

                // Use global functions from script.js to show toast and close modal
                if (typeof showSuccessToast === 'function') showSuccessToast('New walk-in added!');
                if (typeof closeModal === 'function') closeModal();
                newAppointmentForm.reset();
                initializeTableFunctionality('#walk-in-appointments-table'); // Re-initialize the correct table
            };
            newAppointmentForm.addEventListener('submit', handleAppointmentSubmit);
        }


        // --- Open Walk-in Details Modal & Handle Actions ---
        const walkinTableBody = document.querySelector('#walk-in-appointments-table tbody');
        if (walkinTableBody) {
            walkinTableBody.addEventListener('click', (e) => {
                const cancelButton = e.target.closest('.cancel-btn');
                const startServiceButton = e.target.closest('.start-service-btn');
                const completeServiceButton = e.target.closest('.complete-service-btn');
                const markPaidButton = e.target.closest('.mark-paid-btn');
                const technicianSelect = e.target.closest('.technician-select');
                const row = e.target.closest('tr');

                if (!row || row.classList.contains('no-results-row')) return;

                if (startServiceButton) {
                    const walkin = sampleWalkins.find(w => w.plate === row.dataset.plate && w.service === row.dataset.service);
                    if (walkin && walkin.status === 'Pending') {
                        const startTime = new Date().toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true }); // prettier-ignore
                        walkin.status = 'In Progress';
                        walkin.startTime = startTime;
                        row.dataset.status = 'In Progress';
                        row.dataset.startTime = startTime; // prettier-ignore
                        const statusCell = row.querySelector('td:nth-last-child(3)'); // The 3rd cell from the end is Status
                        statusCell.innerHTML = `<span class="in-progress">In Progress</span>`;

                        // Show success toast
                        if (typeof showSuccessToast === 'function') showSuccessToast(`Service for walk-in ${walkin.plate} has started.`);

                        // Replace the start button with a complete button
                        const actionsCell = startServiceButton.parentElement;
                        startServiceButton.remove();
                        actionsCell.insertAdjacentHTML('afterbegin', `
                            <button class="action-icon-btn complete-service-btn" title="Complete Service">
                                <span class="material-symbols-outlined">check</span>
                            </button>
                        `);
                    }
                    return;
                }

                if (completeServiceButton) {
                    const walkin = sampleWalkins.find(w => w.plate === row.dataset.plate && w.service === row.dataset.service);
                    if (walkin && walkin.status === 'In Progress') {
                        walkin.status = 'Completed';
                        row.dataset.status = 'Completed';
                        const statusCell = row.querySelector('td:nth-last-child(3)'); // The 3rd cell from the end is Status
                        statusCell.innerHTML = `<span class="completed">Completed</span>`;

                        if (typeof showSuccessToast === 'function') showSuccessToast(`Service for walk-in ${walkin.plate} is complete.`);
                        completeServiceButton.remove();
                    }
                    return;
                }

                if (cancelButton) {
                    // Find walkin by plate and service to be more specific
                    const walkin = sampleWalkins.find(w => w.plate === row.dataset.plate && w.service === row.dataset.service);
                    if (walkin) {
                        walkin.status = 'Cancelled';
                        row.dataset.status = 'Cancelled';
                        const statusCell = row.querySelector('td:nth-last-child(3)'); // The 3rd cell from the end is Status
                        statusCell.innerHTML = `<span class="cancelled">Cancelled</span>`;
                        
                        cancelButton.disabled = true;
                        // Re-initialize the global function from script.js
                        if (typeof window.initializeTableFunctionality === 'function') window.initializeTableFunctionality('#walk-in-appointments-table');
                    }
                    return;
                }

                if (markPaidButton) {
                    const walkin = sampleWalkins.find(w => w.plate === row.dataset.plate && w.service === row.dataset.service);
                    if (walkin && walkin.paymentStatus === 'Unpaid') {
                        walkin.paymentStatus = 'Paid';
                        row.dataset.paymentStatus = 'Paid';

                        const paymentCell = row.querySelector('td:nth-last-child(2)');
                        paymentCell.innerHTML = `<span class="payment-status-badge paid">Paid</span>`;

                        if (typeof showSuccessToast === 'function') showSuccessToast(`Walk-in for ${walkin.plate} marked as paid.`);
                        
                        // Remove the button after it's clicked
                        markPaidButton.remove();
                    }
                    return;
                }

                // If the click was on the row itself (but not on a button), show details overlay
                const isActionButtonClick = startServiceButton || completeServiceButton || cancelButton || markPaidButton || technicianSelect;
                if (!isActionButtonClick) {
                    const walkin = sampleWalkins.find(w => w.plate === row.dataset.plate && w.service === row.dataset.service);
                    if (walkin) {
                        // Store the selected walk-in data and navigate
                        sessionStorage.setItem('selectedProfileData', JSON.stringify(walkin));
                        window.location.href = `customer-profile.html`;
                    }
                }
            });
        }

        // Initial Setup
        updateAppointmentWidgets();
        populateAppointmentsTable();
        populateWalkinsTable();
        // The global function from script.js will handle this.
        if (typeof window.initializeTableFunctionality === 'function') {
            window.initializeTableFunctionality('#main-appointments-table');
            window.initializeTableFunctionality('#walk-in-appointments-table');
        }
    }
});